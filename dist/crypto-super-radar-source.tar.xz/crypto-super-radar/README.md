# CRYPTO SUPER RADAR

**Quantitative Crypto Intelligence Platform — Persian-first, zero-cost public-data prototype**

CRYPTO SUPER RADAR is a modular Python research engine for swing-trading (days to weeks). It does not search for a single “best coin”. It screens measurable market conditions, validates independent data sources, evaluates a fixed strategy out of sample, and issues a paper-only `LONG`, `SHORT`, or `NO TRADE` decision.

> **Safety rule / قانون اصلی:** all twelve mandatory gates must be `PASS`. Any `FAIL` or `UNKNOWN` means `NO TRADE`. A high score can never override a failed or unknown gate.

> **Zero-cost scope:** the project has no paid API keys, paid data subscriptions, paid database, hosted service, or paid Python dependency. It runs locally using free public endpoints and open-source packages. Public services can impose rate limits, restrict geographic access, change schemas, or become unavailable; €0 does not mean unlimited or guaranteed availability.

## 1. What is implemented

| Stage | English module | توضیح فارسی |
|---|---|---|
| 1 | Data Integrity & Cross-validation | قیمت و حجم از دو منبع مستقل مقایسه می‌شود؛ اختلاف بیش از ۵٪ یا Timestamp نامعتبر، دارایی را از مسیر معامله خارج می‌کند. |
| 2 | Market Regime | روند کلی بازار با کندل‌های روزانه BTC و EMA50/EMA200 و بازده ۳۰ روزه ارزیابی می‌شود. |
| 3 | Trend & Structure | EMA20/EMA50/EMA200 و جهت ساختار قیمت برای Swing بررسی می‌شوند. |
| 4 | Momentum & Relative Strength | RSI14 و قدرت نسبی ۳۰ روزه در برابر BTC سنجیده می‌شوند. |
| 5 | Capital Flow & Liquidity | حجم دلاری، عمق نقدینگی DEX، گردش حجم و در بازار Perpetual، Funding و Open Interest بررسی می‌شود. |
| 6 | On-chain / Contract Risk | در Solana اختیار Mint/Freeze و تمرکز حساب‌ها بررسی می‌شود؛ در Ethereum/Base غربالگری GoPlus و تطبیق دقیق Sourcify اجرا می‌شود. این بررسی ممیزی کامل نیست. |
| 7 | News & Sentiment | تیترهای انگلیسی/فارسی، خبر RSS و متن اجتماعی با واژه‌نامه شفاف تحلیل می‌شوند؛ منبع نامعتبر `UNKNOWN` است. |
| 8 | Initial Out-of-sample Validation | استراتژی EMA20/EMA50 با جداسازی زمانی ۷۰/۳۰، هزینه معاملات، Sharpe، Profit Factor و Drawdown ارزیابی می‌شود. |
| 9 | Portfolio & Trade Risk | اندازه موقعیت، بودجه زیان، محدودیت نقدینگی، نسبت سود به زیان و ریسک باز پرتفوی کنترل می‌شوند. |
| 10 | Whale Intelligence | انتقال‌های بزرگ، جریان ورود/خروج صرافی، کیف‌پول‌های بزرگ و معاملات بزرگ CEX رصد می‌شوند؛ پوشش ناقص سیگنال را مسدود می‌کند. |
| 11 | Full Market Sentiment Coverage | خبر RSS، منبع اجتماعی RSS/متن و شاخص Fear & Greed باید پوشش معتبر داشته باشند. |
| 12 | Multi-fold Walk-forward Stability | چند پنجره آزمون زمانی بدون هم‌پوشانی، هزینه‌ها، Drawdown هر Fold و Funding را اعتبارسنجی می‌کند. |

## 2. Supported markets

Use one of these identifiers:

```text
solana:MINT_ADDRESS     DEX token on Solana
base:0xTOKEN_ADDRESS    DEX token on Base
eth:0xTOKEN_ADDRESS     DEX token on Ethereum
cex:BTCUSDT             Spot instrument; LONG only
perp:BTCUSDT            Perpetual instrument; LONG or SHORT if every gate passes
```

**DEX adapters:** GeckoTerminal V2 + DexScreener public API.

**CEX spot adapters:** Binance Spot + Bybit Spot.

**CEX perpetual adapters:** Binance USD-M Futures + Bybit Linear. Funding and open interest are cross-checked; historical funding is required for the perpetual backtest.

**Market benchmark:** Binance Spot BTCUSDT daily candles.

**Solana security RPC:** public Solana mainnet JSON-RPC.

Base and Ethereum market data can be collected, but the generic EVM security adapter intentionally returns `UNKNOWN`. This avoids pretending that a basic `owner()` or bytecode check proves that a contract is free of mint, proxy, blacklist, honeypot, or privileged-role risks. A verified EVM contract-risk adapter is a prerequisite before those assets can receive trade signals.



> **Source package note / راهنمای دریافت سورس:** برای جلوگیری از ناقص‌بودن ساختار فایل‌ها در مرورگر GitHub، نسخه کامل قابل اجرا در آرشیو `dist/crypto-super-radar-source.tar.xz` قرار دارد. ابتدا آرشیو را در یک مسیر جداگانه استخراج کنید و فرمان‌های نصب و اجرا را از داخل پوشه `crypto-super-radar` اجرا کنید:
>
> ```bash
> mkdir -p /tmp/crypto-super-radar
> tar -xJf dist/crypto-super-radar-source.tar.xz -C /tmp
> cd /tmp/crypto-super-radar
> python -m pip install -r requirements.txt
> python -m crypto_super_radar --test
> ```
>
> **English:** The complete executable package is bundled in the source archive. Extract it first; run commands from the extracted project directory.

## 3. Installation

Requires Python 3.10 or later.

```bash
python -m venv .venv
```

Windows PowerShell:

```powershell
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

macOS / Linux:

```bash
source .venv/bin/activate
pip install -r requirements.txt
```

No API key or `.env` file is required for the default public endpoints.

## 4. Run automated tests

```bash
python -m crypto_super_radar --test
```

or:

```bash
python -m unittest discover -s tests -v
```

## 4a. Run a read-only live research scan

From the repository root, rebuild and extract the complete source package first. The legacy engine modules are bundled in the source archive:

```bash
python scripts/rebuild_source_archive.py
mkdir -p /tmp/csr-live
tar -xJf dist/crypto-super-radar-source.tar.xz -C /tmp/csr-live
cd /tmp/csr-live/crypto-super-radar
python -m pip install -r requirements.txt
python -m scripts.live_research_scan --asset cex:BTCUSDT \
  --output reports/live-research-scan-spot.json
python -m scripts.live_research_scan --asset perp:BTCUSDT \
  --output reports/live-research-scan-perpetual.json
```

The JSON report contains the complete gate evidence and decision blockers. The runner is restricted to a single CEX spot/perpetual asset and never submits orders, signs transactions, connects a wallet, or reads private exchange accounts. Any mandatory `FAIL` or `UNKNOWN` must keep the decision at `NO TRADE`. See [Live Provider Acceptance](docs/LIVE_PROVIDER_ACCEPTANCE.md) for the companion real-provider checks and their regional access requirements.

The offline test suite validates accepted and rejected data, timestamp handling, RSI, local sentiment, the 3-state safety layout, twelve-gate behavior, and preservation of all rows in the Pandas master DataFrame. Tests do not call public APIs and do not incur network costs.

## 5. Run a scan

Spot example:

```bash
python -m crypto_super_radar \
  --asset cex:BTCUSDT \
  --headline "Bitcoin institutional adoption increases"
```

Perpetual example:

```bash
python -m crypto_super_radar \
  --asset perp:BTCUSDT \
  --headline "Bitcoin institutional adoption increases"
```

Multi-market example:

```bash
python -m crypto_super_radar \
  --asset cex:BTCUSDT \
  --asset perp:ETHUSDT \
  --asset solana:YOUR_SOLANA_MINT \
  --asset base:YOUR_BASE_TOKEN_ADDRESS \
  --headline "Institutional adoption increases" \
  --headline "No exploit or withdrawal warning reported"
```

Custom public feeds can be supplied without an API key:

```bash
python -m crypto_super_radar \
  --asset cex:BTCUSDT \
  --news-rss "https://www.coindesk.com/arc/outboundfeeds/rss/" \
  --social-rss "https://www.reddit.com/r/CryptoCurrency/.rss" \
  --social-post "Community reports a major adoption upgrade"
```

Save a CSV report:

```bash
python -m crypto_super_radar \
  --asset cex:BTCUSDT \
  --headline "Bitcoin adoption upgrade" \
  --output radar_report.csv
```

`--headline` and `--social-post` can be repeated. By default the integrated CLI also fetches public news RSS, public social/community RSS and the Alternative.me Fear & Greed Index. Override feeds with `--news-rss` and `--social-rss`. If any of the three required sentiment sources is missing, Gate 11 is `UNKNOWN` and no trade is allowed. The text scorer is a transparent keyword baseline, not a trained NLP model.

### Optional Persian Streamlit dashboard (local installation)

Streamlit is an optional UI dependency; it is not installed by the base CLI or the default Render service.

```bash
python -m pip install -e ".[dashboard]"
streamlit run crypto_super_radar/streamlit_app.py
```

The dashboard reads the same `AnalysisResult` as the CLI and builds Pandas DataFrames for all 12 gates, FAIL/UNKNOWN data errors, RSI/EMA/ATR and backtest evidence, whale-flow observations, sentiment and Fear & Greed. It does not create synthetic values for missing evidence.

The default `render.yaml` continues to launch the lightweight HTTP dashboard in `web_app.py`; it has not been switched to Streamlit or deployed. Its build command extracts the bundled legacy engine modules, overlays the current tracked Feature-branch package files, and then installs only `requirements.txt`. This is necessary because the complete source distribution includes compatibility modules retained in the archive. Auto-deploy remains disabled, and this blueprint has not created or changed a Render service. The optional Streamlit runtime is not a mandatory dependency on the constrained Render Free service. Run Streamlit locally first and measure memory use before considering a hosted Streamlit service.

## 6. Global throttling and cross-validation

A shared process-wide, thread-safe singleton limiter spaces requests by host. GeckoTerminal uses a conservative **one request every six seconds** (approximately 10 requests/minute), based on its public API documentation. DexScreener and exchange endpoints also have conservative per-host spacing. HTTP 429 and transient 5xx responses are retried with bounded delays.

Each DEX asset is checked against GeckoTerminal and DexScreener. CEX spot assets are checked against Binance and Bybit; perpetual instruments are checked against Binance USD-M and Bybit Linear, including a funding-rate discrepancy check. A 5% price mismatch rejects the asset. For DEX data, price **and** volume mismatches above 5% reject the asset. CEX trading volumes are not compared across venues because each exchange reports its own traded volume; each venue's turnover is screened against the minimum independently.

A provider returning no data, an unreadable candle timestamp, a missing pool creation timestamp, or insufficient history does **not** become zero, fresh, or safe. The corresponding gate is `UNKNOWN`.

## Elliott-wave structure monitor

The analysis report also contains an optional, price-only Elliott-wave structure
summary. It uses confirmed ZigZag pivots from validated daily candles, applies
standard impulse invalidation checks, and reports candidate phase, confirmed
pivot times, and an invalidation level. A pivot records both where it occurred
and when a later reversal confirmed it, avoiding look-ahead/repainting.
Ambiguous structures remain AMBIGUOUS. Wave labels are scenarios, not
probabilities or independent buy/sell signals; this module does not add a
mandatory gate and cannot alter the 12-gate decision.

## 7. Signal and risk policy

- The initial confirmation threshold is 75/100; it is a tunable research parameter, not a probability of profit.
- **Risk Score** is the model's estimated risk on a 0–100 scale (higher means riskier); **Opportunity Rank** is a separate 0–100 ranking output; **Confidence Level** is raw mandatory-gate coverage adjusted for whale/sentiment disagreement. Confidence is not a probability of profit. Their separate calculation paths do not prove statistical independence or zero correlation; that requires historical validation.
- The default heuristic modifiers are centralized in `IntelligenceScoringConfig`: confirmation uses whale +5/-10 and sentiment +3/-3 for aligned/opposed evidence; risk adds +10 for opposed whale flow, +3 for neutral whale flow, +5 for opposed sentiment, and +1 for neutral sentiment; opportunity uses whale +4/-6 and sentiment +2/-3. Confidence deducts 15 for opposed whale flow, 5 for neutral whale flow, 10 for opposed sentiment, and another 5 when whale and sentiment point in opposite directions. These are transparent starting weights, not learned coefficients; they must be calibrated and re-tested out of sample before being treated as an edge.
- Estimated risk is separate from confirmation score; lower is better.
- Entry/Stop/Target use daily ATR14. Default SL distance is 2×ATR and TP distance is 4×ATR (2:1 nominal reward/risk before gaps and execution effects).
- Paper sizing starts from a configurable simulated equity of $10,000 and a 0.50% risk budget per trade. It does not read a real account balance.
- Position notional is capped by simulated equity and a conservative liquidity/volume participation proxy.
- `LOW_RISK` is only a relative model label. It is not a guarantee of capital safety.
- Spot and DEX markets cannot issue a short-sale signal. `SHORT` is considered only for a verified perpetual market with funding and open-interest evidence.
- The scanner never submits exchange orders, connects to wallets, signs transactions, or stores private keys.

## 8. Important limitations before real capital

1. **EVM contract security is a minimum screen, not an audit.** GoPlus risk fields and exact Sourcify source matching are required; missing fields remain `UNKNOWN`. Proxy contracts, privileged controls, honeypot flags, high taxes or holder concentration can fail the screen. Liquidity locks, upgrade governance and every possible attack path are not certified.
2. **Solana security is a minimum screen, not an audit.** Mint and Freeze authority status plus top-10 token-account concentration do not prove LP locking or eliminate hidden program risks. Token accounts are not the same as beneficial wallet owners; LP/exchange accounts can distort concentration.
3. **Order-book depth is not available in the public DEX adapters.** DEX liquidity is a pool-reserve proxy. CEX size caps use quote-volume as a conservative proxy, not a measured order-book slippage curve.
4. **Sentiment is a transparent baseline.** The integrated CLI fetches public RSS and Alternative.me Fear & Greed, and can consume public social RSS or supplied social text. It does not use paid X/Twitter APIs, does not infer missing sources, and is not a trained NLP model. It cannot claim a statistically measured *sudden* attention spike without a historical baseline.
5. **Backtesting is not proof of a persistent edge.** The original 70/30 OOS gate is supplemented by a fixed EMA20/EMA50 multi-fold validation gate. Perpetual multi-fold validation remains `UNKNOWN` if funding history does not cover every required day. Survivorship-bias controls, token delisting history, regime-specific analysis, realistic spread/impact, liquidation mechanics, and portfolio-level correlation/tail-risk stress tests remain future work.
6. **Free APIs are not SLAs.** Providers can change rate limits, schemas, availability, and geographic access. The rate limiter reduces risk but cannot guarantee the IP will never be throttled.

Do not deploy this prototype as an unattended live trading bot. First complete live-provider verification, historical market-universe reconstruction, realistic execution simulation, and a sustained paper-trading observation period.

## 9. Professional references

- GeckoTerminal V2 public API: <https://api.geckoterminal.com/docs/index.html>
- DexScreener API reference: <https://docs.dexscreener.com/api/reference>
- Binance Spot API: <https://github.com/binance/binance-spot-api-docs>
- Binance USD-M Futures API: <https://developers.binance.com/docs/derivatives/usds-margined-futures/market-data/rest-api>
- Bybit V5 API: <https://bybit-exchange.github.io/docs/v5/intro>
- Solana JSON-RPC: <https://solana.com/docs/rpc/http>
- GoPlus Token Security API: <https://docs.gopluslabs.io/>
- Sourcify verification API: <https://docs.sourcify.dev/>
- Alternative.me Crypto Fear & Greed API: <https://alternative.me/crypto/api/>


## 10. Whale intelligence, sentiment and multi-fold validation (new research modules)

The feature branch adds the following explicit research APIs:

| Module | Capability | Important boundary |
|---|---|---|
| `whale_intelligence.py` | Classifies large transfers, exchange inflows/outflows and labelled-entity movements | A transfer is not proof of a buy or sell; unknown labels remain unattributed |
| `evm_transfers.py` | Bounded ERC-20 Transfer-log scanning on Ethereum and Base public JSON-RPC | Requires a valid USD price to size whales; block-range and log-count caps prevent uncontrolled RPC use |
| `solana_whales.py` | Samples recent transactions for the largest SPL token accounts | Explicitly partial coverage; not a full historical Solana indexer or proof of beneficial ownership |
| `sentiment.py` | Persian/English news/social/positioning keyword scoring, Fear & Greed normalization and divergence flags | Transparent baseline; not a trained NLP model |
| `sentiment_feeds.py` | Public RSS headlines and Alternative.me Fear & Greed API | Free public sources with caching/rate limiting; no paid news feed |
| `market_sentiment.py` | Combined news RSS + social RSS/text + Fear & Greed | Missing social coverage keeps the sentiment gate PARTIAL/blocked |
| `evm_security.py` | GoPlus token-security checks plus Sourcify source verification | Requires exact Sourcify match; proxy/admin and missing fields are not assumed safe |
| `walk_forward.py` | Non-overlapping chronological out-of-sample folds, costs and per-fold drawdown | Requires a causally generated return series; historical funding is mandatory for perpetuals |
| `intelligence_engine.py` | Fail-closed combination of whale, sentiment, market, derivatives, security and validation states | Any mandatory `FAIL` or `UNKNOWN` blocks the research signal |
| `integrated_engine.py` | Connects whale, sentiment and 12-gate walk-forward checks to the legacy engine | اتصال ماژول‌ها به موتور اصلی و ۱۲ فیلتر اجباری |
| `cex_whales.py` | Cross-venue large-trade flow from Binance and Bybit | تشخیص جریان معاملات بزرگ در دو صرافی |
| `enhanced_cli.py` | Integrated CLI entry point with RSS configuration | رابط خط فرمان یکپارچه |
| `whale_store.py` | Local SQLite history for repeated whale-flow observations | ذخیره محلی تاریخچه حرکت نهنگ‌ها |
| `web_app.py` | Persian on-demand dashboard, job polling and history endpoint | داشبورد وب فارسی برای اسکن و تاریخچه |

### Whale-flow interpretation

- Net exchange inflow is a **potential increase in sell-side supply**, not evidence that the coins were sold.
- Net exchange outflow can indicate custody or accumulation, but does not prove spot buying.
- EVM top-holder watchlists can be derived from GoPlus holder percentages and token supply; Solana token-account owners are resolved through public RPC. Both are partial samples, not a complete wallet universe.
- A wallet is only identified as an exchange, fund, market maker or smart-money entity when an upstream label is explicitly supplied. The engine does not invent wallet identities.
- Solana sampling only inspects a bounded recent subset of the largest token accounts. Its coverage status stays `PARTIAL`; the unified engine will not treat that as a complete whale confirmation.

### Example: offline sentiment and transfer analysis

```python
from crypto_super_radar.whale_intelligence import analyze_whale_activity
from crypto_super_radar.sentiment import analyze_market_sentiment, detect_sentiment_divergence

whales = analyze_whale_activity(normalized_transfer_rows)
sentiment = analyze_market_sentiment({
    "news": ["Institutional adoption increases"],
    "social": ["Community reports a major exploit"],
})
divergence = detect_sentiment_divergence(
    sentiment.get("score"),
    whales.get("net_exchange_flow_usd"),
)
print(whales)
print(sentiment)
print(divergence)
```

### Release boundary

These modules are committed on the feature branch and covered by offline tests. They are **research components**, not yet evidence of a live end-to-end production scan. No live market scan, sustained wallet monitoring, or unattended trading has been run. EVM and Solana wallet watchlists are bounded top-holder samples; CEX whale flow is a recent large-trade sample, not wallet attribution. The integrated CLI/report path is wired to these modules. It still requires live-provider verification and sustained Paper Trading before the separate Render service is created. The CI workflow rebuilds the bundled source archive and publishes it as an artifact; the original archive in the repository is not treated as updated until that CI job succeeds.




## 14. Market overview and scenario calculator

The Streamlit dashboard includes an OHLC candlestick view, per-asset and benchmark regime labels (bullish / bearish / neutral / unknown), and observed high/low extrema for 7, 30, 90 and 365 calendar-day windows. A range is shown as `KNOWN` only when timestamps, OHLC consistency, freshness and minimum window coverage pass validation; insufficient history, stale candles, duplicate timestamps or malformed bars remain `UNKNOWN`. These extrema are observed historical ranges, not guaranteed support/resistance levels.

The Spot scenario calculator is an unleveraged long-only arithmetic tool. For investment (I), assumed price move (r), buy/sell fee fractions (f_b,f_s), and buy/sell slippage fractions (s_b,s_s):

`V_net = I × (1-f_b) × (1-s_b) × (1+r) × (1-s_s) × (1-f_s)`

`Net P/L = V_net − I`

Break-even price appreciation is `1 / ((1-f_b)(1-s_b)(1-s_s)(1-f_s)) − 1`. The user-selected horizon is a scenario label only; the calculator does not estimate the time or probability of reaching a target. Taxes, EUR/USD FX changes, custody/network charges and market impact beyond the supplied slippage assumptions are excluded. The calculator never submits orders and does not relax any of the twelve mandatory research gates.

## 13. RSS provider coverage semantics

A configured RSS set is reported as `KNOWN` only when every configured feed returns at least one titled item and none of the feeds fails. If some feeds return usable headlines while another fails or returns no titled items, the source is `PARTIAL`; the full-market-sentiment gate must remain blocked. Whitespace-only manually supplied social text is not accepted as social coverage. This is a coverage control, not a claim that RSS feeds represent the entire news or social universe.

---

**CRYPTO SUPER RADAR** — Discover Early. Analyze Smarter. Manage Risk.


## 11. Geometric chart-pattern monitoring

The research scan now checks confirmed, non-repainting pivots for symmetrical, ascending and descending triangle structures. A forming pattern requires three confirmed contacts on each boundary, contracting price range and fitted trend lines. The latest candle close must move beyond a small boundary buffer before the pattern is labeled as a breakout. This remains outside the 12-gate count and does not add score. A confirmed triangle breakout that directly opposes the independently calculated market direction vetoes a research signal; forming, ambiguous or missing patterns do not. The monitor never creates an order.

The Persian web chart draws the upper/lower boundaries and confirmed pivot points with the browser's built-in canvas renderer. A breakout can veto an opposing signal only after relative volume reaches 1.2x its prior 20-bar median and the candle closes near the relevant extreme. Daily analysis excludes the newest still-open daily candle to avoid intraday repainting. These safeguards add no paid charting library, AI call or external chart service. Pattern matching is a rule-based approximation and should be reviewed with out-of-sample data before any strategy use.

## 12. Optional AI headline enrichment (Gemini)

AI is an **optional explanatory layer**, not part of the deterministic scoring or trade-decision path. The engine continues to calculate technical indicators, whale evidence, sentiment baseline, Risk Score, Opportunity Rank, Confidence Level and all 12 mandatory gates when AI is disabled or unavailable.

To enable it on Render without changing the Blueprint or committing a secret:

1. Create a Gemini API key in [Google AI Studio](https://aistudio.google.com/apikey).
2. In the Render Dashboard, open the existing CRYPTO SUPER RADAR service and add these variables under **Environment**:
   - `GEMINI_API_KEY`: the private key from AI Studio
   - `CSR_AI_PROVIDER`: `gemini`
   - `CSR_GEMINI_MODEL`: `gemini-2.5-flash`
3. Save the environment changes when you are ready to apply them. This repository change does not create, edit, or deploy a Render service.

For local use, copy the optional examples from `.env.example` into an untracked `.env` file and load them through your own process environment. Never commit keys or expose them in browser code.

The Gemini Developer API currently lists a free tier for Gemini 2.5 Flash, but limits and model availability can change. Google's free-tier terms state that submitted content may be used to improve its products; this integration therefore sends only public headline text, never private user or trading data. Do not enable it unless those terms are acceptable.

```text
GEMINI_API_KEY=<server-side secret>
CSR_AI_PROVIDER=gemini
CSR_GEMINI_MODEL=gemini-2.5-flash
```

`GEMINI_API_KEY` is intentionally optional. Without it, AI enrichment reports `DISABLED`; the regular sentiment pipeline continues normally. The gateway sends only a bounded set of public news headline titles/summaries to Gemini. It does not send user-supplied social posts, wallet addresses, portfolio holdings, private keys, or trade plans.

The response is constrained to a small JSON schema (summary, themes, risk flags, conflicting evidence). Invalid JSON, schema violations, authentication failures, quota errors, timeouts, and provider outages become `UNKNOWN` enrichment; none can change numeric sentiment, open a gate, or override `NO TRADE`. Results are cached in-process for 15 minutes. Render Free may clear this cache when the service sleeps or restarts.

**Privacy and quota note:** Gemini API free-tier eligibility, model availability, rate limits and data-use terms can change. Check the current Google AI Studio/API terms before enabling it. Do not send confidential or proprietary material to a free-tier provider unless its current data-use terms are acceptable. No provider key is included in this repository and no Render environment variable or service has been changed.

## 15. Public market-provider data validation

Provider adapters apply strict normalization before market data reaches the gates:

- Prices and open interest must be finite and strictly positive; volumes and token supplies must be finite and non-negative. Boolean values are not numeric evidence.
- Funding rates are signed values. Negative funding is valid and is preserved; missing, non-finite, stale, duplicated, or cross-venue-conflicting funding remains an error/UNKNOWN condition.
- Binance and Bybit perpetual funding observations are checked for a matching settlement interval, timestamp proximity and rate agreement before historical values are combined. Binance's documented 8-hour default is used only when its adjusted-interval endpoint has no entry for the symbol; Bybit's instrument metadata must provide the interval in minutes. An absent Bybit success code or malformed API envelope is rejected even when the HTTP response itself is successful.
- OHLCV rows with duplicate or fractional timestamps, future timestamps, missing/non-finite prices, or inconsistent high/low ranges are rejected. An entirely unusable candle response becomes an empty history so downstream freshness/coverage checks remain UNKNOWN; a mixed response containing valid and invalid timestamp rows is rejected as a whole.
- HTTP retries are limited to transient network errors, 408/425/429 and server errors. Retry-After delta-seconds and HTTP-date values are supported with a 30-second cap; non-retryable client errors fail immediately.

These checks validate response shape and internal consistency; they do not prove that a public provider is correct, independent, manipulation-free, or continuously available. CI uses mocked/offline fixtures and does not replace a live-provider acceptance test. All 12 mandatory gates remain fail-closed, and no order execution is enabled.


## 16. Free cryptocurrency market board

The default lightweight HTTP dashboard now includes a small, curated spot-market board for BTC, ETH, SOL, BNB, XRP and DOGE. It uses the existing public Binance Spot and Bybit Spot adapters, requires no API key or paid data subscription, and displays a price only when both sources return valid data within the configured discrepancy limit. The server caches results for 60 seconds to limit public API traffic. See [Dashboard Design](docs/DASHBOARD_DESIGN.md) for the visual system and interaction notes. If a provider is unavailable or the venues disagree, that row remains `UNKNOWN`; the board is not a market-cap ranking or a trading recommendation. A verified row can prefill the research scan form; it never starts the scan automatically.


## 13. Integrated paper trading bot

A free paper-trading bot is available for BTCUSDT, ETHUSDT and SOLUSDT spot. It scans through the existing 12 mandatory gates, opens only LONG paper positions, and manages exits using the engine's stop-loss and take-profit levels. Every signal needs all gates PASS, confirmation score at least 75, estimated risk below 45, a valid stop/target plan, and net reward/risk of at least 1.8 after costs. Position sizing risks at most 0.5% of paper equity and caps notional at 10%; the simulation includes 8 bps fee and 10 bps slippage per side and permits one open position at a time. Entries are deduplicated per completed daily candle. Stops move above estimated break-even after +1R and trail the peak by 1R after +1.5R; positions also receive a maximum holding time. Daily realized loss above 1.5%, peak-to-trough equity drawdown above 10%, three consecutive losses, or a 24-hour asset cooldown after a losing trade pauses new entries. These circuits do not prevent the bot from managing or closing an already-open paper position.

The dashboard's **ربات معامله‌گر آزمایشی** section can run one on-demand cycle. For repeated free local operation, run:

```text
python scripts/paper_trading_bot.py --asset cex:BTCUSDT --interval-seconds 900
```

Use Ctrl+C to stop. State and closed trades are stored in the local SQLite database configured by `CSR_DB_PATH`. Render Free can sleep and reset its local filesystem, so it is not a durable always-on bot host.

This bot is explicitly paper-only: it has no exchange order adapter, API-key input or live-order mode. It never submits exchange orders. Paper fills are estimates from cross-validated public spot prices, fee assumptions and slippage; they are not guaranteed executable fills.


## BloFin Demo Futures autonomous pilot

The isolated branch `feature/blofin-demo-adapter` now combines the GET-only `crypto_super_radar.blofin_demo_readonly` adapter with the guarded `crypto_super_radar.blofin_demo_executor`. Both REST clients are pinned to `https://demo-trading-openapi.blofin.com`; no production exchange host, transfers, withdrawals, or wallet signing are implemented.

The process-local scheduler starts only when `BLOFIN_DEMO_AUTOPILOT_ENABLED=true`. It reads `BLOFIN_DEMO_AUTOPILOT_INSTRUMENT` (default `BTC-USDT`) and `BLOFIN_DEMO_AUTOPILOT_PROFILE` (default `EASY`). The UI also lets a human choose a live **USDT-margined linear perpetual SWAP** from BloFin's catalog (only `state=live`, `contractType=linear`, `settleCurrency=USDT`, `apiPermission=full`) and choose EASY, STANDARD or STRICT. The human selects the market and robot profile; LONG/SHORT direction is produced only by the live signal engine.

- **EASY** uses seven mandatory controls: completed/fresh data, directional 1H regime, trend alignment, completed 15m momentum trigger, spread/turnover/mark-price quality, tradable full-permission contract, and account/portfolio risk. News, broad sentiment, whale coverage and walk-forward evidence stay visible as their actual PASS/FAIL/UNKNOWN values; they are advisory in this profile and are never rewritten as PASS. A special candlestick pattern is not required.
- **STANDARD** requires gate IDs 1, 2, 3, 4, 5, 6, 8 and 9 to PASS, at least nine PASS gates overall, and the higher confirmation-score threshold.
- **STRICT** requires all 12 unique gates to PASS and the strict confirmation threshold.

The 1H trend and completed 15m momentum trigger must align before any profile can enter. The unique signal key is the selected instrument plus the completed 15m candle timestamp, so a new candle can create a new opportunity within the same UTC day after the prior position is closed. Nemotron receives the same selected profile and may veto an entry; it cannot waive a required gate or any account, permission, price, order, margin or risk guard. A missing/invalid AI answer, stale/missing required data, a failed required gate, invalid instrument permission, clock mismatch, price deviation, account read failure, pending order, or risk-limit breach blocks entry. An ambiguous order response is reconciled using READ-only order-detail calls; the runner never blindly resends the order.

BloFin Demo policy is: **unlimited order count across the service lifetime and per UTC day**, no artificial strategy cooldown between resolved cycles, **1x isolated leverage**, at most **0.25% account-equity risk per trade**, one concurrent position, **1% daily loss stop**, **5% peak-to-trough drawdown stop**, and at most **10% isolated-margin usage**. A new order is permitted only after the prior position is closed and any ambiguous order outcome has been reconciled. Each completed 15m candle is idempotent. Exchange write requests still pass through the endpoint rate limiter. Order reservations and append-only lifecycle events persist in Turso.

Set these controls only on the isolated Render Demo service:
- `BLOFIN_DEMO_AUTOPILOT_ENABLED=true`
- `BLOFIN_DEMO_AUTOPILOT_INSTRUMENT=BTC-USDT` (or another full-permission USDT linear SWAP returned by the live catalog)
- `BLOFIN_DEMO_AUTOPILOT_PROFILE=EASY` (or `STANDARD` / `STRICT`)
- Optional `BLOFIN_DEMO_AUTOPILOT_INTERVAL_SECONDS=300` (default 5-minute polling; clamped to 300–900 seconds)
- Existing server-side `BLOFIN_DEMO_API_KEY`, `BLOFIN_DEMO_API_SECRET`, and `BLOFIN_DEMO_PASSPHRASE` must belong to a **Demo-only key with actual TRADE permission**. The exchange instrument response must confirm `apiPermission=full`; a READ-only key is not sufficient. Dedicated `BLOFIN_DEMO_TRADE_*` variables take precedence when configured.
- `BLOFIN_DEMO_TRADING_ENABLED=true`, `BLOFIN_DASHBOARD_TOKEN`, both Turso variables, and a working free Nemotron/OpenRouter configuration must also exist.

Never paste secrets into GitHub, Notion, browser code, chat, or source files. Keep TRANSFER and withdrawal permissions disabled. Do not enable the scheduler on Production. Readiness at `/api/blofin/demo/execution-readiness` is only a prerequisite summary; the instrument permission, 12 gates, AI, account state, and risk checks are re-evaluated during each cycle. Runtime status is available from `/api/blofin/demo/autopilot/status`.

**Hosting limit:** Render Free web services can sleep after 15 minutes without inbound traffic. This in-process scheduler therefore runs only while the web process is awake; it does not guarantee 24/7 autonomous execution on the Free plan. It is not a managed background worker or a guaranteed always-on trading service. CI tests use mocked exchange responses and do not prove live Demo API permission or successful fills. Binance Spot Testnet and the local Futures Paper Trading ledger remain separate environments.

## Binance Spot order execution (testnet first)

A guarded execution adapter is available in `crypto_super_radar.binance_execution`. It accepts only BTCUSDT, ETHUSDT and SOLUSDT spot orders, sends limit IOC orders, checks the live quote against the signal price, exchange quantity/price/minimum-notional filters, free balance, and a hard 25 USDT per-order ceiling. `ValidatedSignalExecutor` accepts only a LONG result with all 12 gates passing, score at least 75, risk score below 45, a valid stop/target, and net reward/risk at least 1.8. Position sizing risks at most 0.5% of free USDT.

Set testnet API credentials in `CSR_BINANCE_API_KEY` and `CSR_BINANCE_API_SECRET`; the default environment is Binance Spot Testnet. Use API keys with trading permission only on the testnet account. The adapter does not retry a timed-out order. It returns the client order id so the caller can reconcile status with `get_order` before doing anything else.

**Production execution is deliberately locked.** Exchange-side stop/target orders, fill reconciliation, and recovery after a process restart are not implemented, so the production lock cannot be overridden with an environment variable. After those controls are implemented and tested, production will also require `CSR_BINANCE_ENV=production`, `CSR_LIVE_TRADING_ENABLED=YES`, and the explicit per-call confirmation value `I_CONFIRM_REAL_SPOT_ORDER`. Never put API keys in the repository or dashboard request fields. This adapter does not currently wire order execution into the dashboard's periodic paper-bot loop.


## Pre-trade market-history and structure gate

The engine now strengthens its existing final gate with confirmed swing highs/lows, a robust ATR scale, Fibonacci retracement confluence, and a chronological historical-analogue check. It compares normalized 20-candle return shapes to separated prior episodes; all analogue outcomes must be observed before the current pattern window. The output reports the analogue sample size, cost-adjusted historical hit/error estimate, a Wilson 95% confidence bound, net expectancy, worst observed adverse move, and structural stop/target levels.

This is an empirical screening estimate, not a true future error probability. It fails closed when history is incomplete, the market structure conflicts with the signal, Fibonacci confluence is absent, uncertainty is too wide, or structural net reward/risk is below 1.8. Elliott-wave and chart-shape labels remain contextual evidence, not stand-alone buy/sell triggers. The signal execution service also requires this gate and the exact structural stop/target returned by the analysis.

## Optional persistent cloud storage (Turso)

The dashboard can keep its existing SQLite schema while storing it in a remote Turso database. This persists whale observations and the paper-trading account, open paper position, and trade journal across Render restarts. The local SQLite backend remains the default when Turso is not configured.

1. Create a separate database for this application in the [Turso dashboard](https://turso.tech/app) using the Free plan.
2. Copy the database URL and create a read/write database token in Turso.
3. In Render, open **Environment** for `crypto-super-radar` and add both variables:
   - `TURSO_DATABASE_URL` — the database URL from Turso.
   - `TURSO_AUTH_TOKEN` — the server-side database token.
4. Save the variables and allow Render to redeploy. The application creates its required tables automatically on first startup.

Keep the token only in Render's private environment variables. Never commit it to GitHub, place it in browser JavaScript, or paste it into public issue reports. Both variables must be configured together; a partial configuration fails closed rather than silently writing to temporary local storage.

The scan queue and in-progress browser job registry are still in-memory and are not durable across a process restart. Market prices and provider evidence are fetched live; no synthetic historical market dataset is seeded into the database. There is no historical database file in the repository to import, so the new cloud database begins empty and accumulates real observations after activation.



## Required free AI second opinion for Paper Trading

The Spot paper bot now requires a real hosted LLM review before opening **any new** paper position. It uses the OpenRouter OpenAI-compatible API with the free NVIDIA Nemotron model variant:

```text
OPENROUTER_API_KEY=<your-free-openrouter-key>
CSR_AI_MODEL=nvidia/nemotron-3-ultra-550b-a55b:free
```

1. Create a free OpenRouter account and API key at <https://openrouter.ai/keys>.
2. Add `OPENROUTER_API_KEY` to the server environment (Render → service → Environment). Do not add it to Git, source files, browser code, dashboard forms or issue reports.
3. Keep the default model ID ending in `:free`. The adapter rejects model IDs without that suffix, preventing an accidental switch to paid inference.
4. The dashboard reports whether a key is configured. A successful connection is confirmed only after the first real review.

OpenRouter currently lists free model variants at $0 per input/output token and a free-account limit of 50 requests/day; free variants with the `:free` suffix do not require a credit purchase. The app enforces conservative per-process caps of 35 requests/day and 18 requests/minute, plus a four-hour evidence cache. The minute cap is deliberately below OpenRouter's published 20 requests/minute free limit; with multiple app instances, these local caps are per process rather than a shared global quota. Actual provider availability, daily limits and free model availability can change; a provider 429, outage, invalid response, missing key or quota exhaustion produces `UNKNOWN`/blocked entry, never a fallback to paid inference.

The AI acts as one language model taking eight specialist roles (market regime, technical, news/sentiment, bull researcher, bear researcher, trader, risk manager and portfolio manager). This is an evidence-bounded, single-model committee emulation, **not** eight independent models and not the original TradingAgents model weights. The local deterministic council independently checks the exact 12-gate set before any LLM request. Only a strict, valid Buy/Overweight response with explicit trader LONG, risk-manager APPROVE, portfolio-manager APPROVE and no risk flags can pass the additional AI veto. The existing radar gates, paper sizing, execution-cost model and circuit breakers remain independently mandatory.

Existing open paper positions continue to be managed and can be closed using the radar's existing stop/target/time rules even when the AI key is missing or the free service is unavailable. The AI key is needed only for new paper entries.

Only a compact allowlist of public market evidence and gate statuses is sent to the model. Wallet addresses, balances, holdings, exchange credentials, API keys and private user data are not sent. **Provider data-use notice:** the free NVIDIA endpoint page says requests may be logged for security and used to improve NVIDIA products. Do not send confidential information to this free endpoint. The bot's request contains public market statistics, but users should review the provider's current terms.

The optional Gemini headline-enrichment section elsewhere in this README is a separate feature; it is not required by this Paper Trading AI integration.


## Independent multi-provider AI Supervisor (Challenge 1 Demo)

Challenge 1 Demo entries now require **at least two independent, model-verified AI approvals** in addition to the deterministic strategy and risk gates. A valid veto from any responding provider blocks the entry. One provider alone, missing providers, rate limits, invalid JSON, unverified model identity, or fewer than two approvals all fail closed. This is an AI approval gate, not a promise of trading profitability.

Supported providers are configured with server-side environment variables only:

| Provider | Secret environment variable | Fixed model / endpoint |
|---|---|---|
| NVIDIA Nemotron through OpenRouter | `OPENROUTER_API_KEY` (or existing `CSR_OPENROUTER_API_KEY`) | `nvidia/nemotron-3-ultra-550b-a55b:free` |
| Google Gemini | `GEMINI_API_KEY` | `gemini-3.8-flash` via Google's OpenAI-compatible endpoint |
| Groq | `GROQ_API_KEY` | `openai/gpt-oss-120b` |

**Zero-cost requirements:** keep OpenRouter on the `:free` model; use Google AI Studio Free tier with no billing account linked; keep Groq on its Free plan and do not upgrade to Developer. The application never switches to a paid model automatically. Provider quotas can still return 429/availability errors, in which case new entries are blocked. Google AI Studio Free tier may use submitted content to improve Google products, and OpenRouter free inference may be logged by the upstream provider; only sanitized public market metrics and gate evidence are sent. Never send exchange secrets, account balances, wallet/private-key data, or user-identifying information.

For the unattended GitHub Actions worker, add at least two provider keys as **GitHub repository Actions secrets**: `OPENROUTER_API_KEY` (or `CSR_OPENROUTER_API_KEY`), `GEMINI_API_KEY`, and/or `GROQ_API_KEY`. PR #36 adds those secret references to the scheduled workflow on the default `main` branch; the values themselves must be created by the repository owner in Settings → Secrets and variables → Actions. For the Staging dashboard and its synthetic dry-run, also add the same chosen keys to the **Render Staging service** environment variables. Do not paste secrets into GitHub source files, Notion, or chat. After the keys are added and the Staging code is approved, verify `GET /api/ai/status` and run the synthetic AI dry-run. The dashboard must show at least two configured providers and two independently validated approvals before any Demo entry can pass the AI gate.

The Challenge 1 local-rules-only bypass is removed for Demo entries: deterministic analysis still runs, but a new entry cannot proceed without the multi-provider supervisor quorum. Live trading, transfers, withdrawals, and Production changes remain out of scope.
