"""BloFin Demo Futures read-only adapter.

This module is intentionally incapable of submitting, amending, cancelling,
transferring, or withdrawing. The REST host is pinned to BloFin Demo.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import os
import time
import uuid
from decimal import Decimal, InvalidOperation
from typing import Any, Mapping
from urllib.parse import urlencode

import requests

DEMO_REST_URL = "https://demo-trading-openapi.blofin.com"
DEMO_PUBLIC_WS_URL = "wss://demo-trading-openapi.blofin.com/ws/public"
DEMO_PRIVATE_WS_URL = "wss://demo-trading-openapi.blofin.com/ws/private"
WS_LOGIN_PATH = "/users/self/verify"

# BloFin account-level credentials are shared across Live and Demo. The API
# host selects the environment; this adapter is permanently pinned to Demo.
# Keep legacy Demo-prefixed names supported for existing deployments.
DEMO_READ_CREDENTIAL_ENV = {
    "api_key": ("BLOFIN_API_KEY", "BLOFIN_DEMO_API_KEY"),
    "api_secret": ("BLOFIN_API_SECRET", "BLOFIN_DEMO_API_SECRET"),
    "passphrase": ("BLOFIN_PASSPHRASE", "BLOFIN_DEMO_PASSPHRASE"),
}
DEMO_TRADE_CREDENTIAL_ENV = {
    "api_key": ("BLOFIN_DEMO_TRADE_API_KEY", "BLOFIN_API_KEY", "BLOFIN_DEMO_API_KEY"),
    "api_secret": ("BLOFIN_DEMO_TRADE_API_SECRET", "BLOFIN_API_SECRET", "BLOFIN_DEMO_API_SECRET"),
    "passphrase": ("BLOFIN_DEMO_TRADE_PASSPHRASE", "BLOFIN_PASSPHRASE", "BLOFIN_DEMO_PASSPHRASE"),
}


def _resolve_env_credential(env_names: tuple[str, ...]) -> tuple[str, str]:
    """Return the first configured credential and its variable name, not its value."""
    for env_name in env_names:
        raw = os.getenv(env_name)
        if raw is not None and raw.strip():
            return raw.strip(), env_name
    return "", " or ".join(env_names)


class BloFinDemoError(RuntimeError):
    """Base error for the read-only BloFin Demo adapter."""


class BloFinDemoAuthError(BloFinDemoError):
    """Missing or rejected read-only API credentials."""


class BloFinDemoResponseError(BloFinDemoError):
    """Unexpected or unsuccessful BloFin response."""


class BloFinDemoHTTPError(BloFinDemoError):
    """Sanitized HTTP failure with a safe retry hint."""

    def __init__(self, status_code: int, retry_after_seconds: float | None = None):
        self.status_code = int(status_code)
        self.retry_after_seconds = retry_after_seconds
        super().__init__(f"BloFin Demo HTTP request failed (status={self.status_code}).")


def _positive_decimal_text(value: Any, field: str) -> str:
    """Validate exchange contract metadata without passing through binary float."""
    try:
        number = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise BloFinDemoResponseError(
            f"Instrument {field} must be a valid decimal string."
        ) from exc
    if not number.is_finite() or number <= 0:
        raise BloFinDemoResponseError(
            f"Instrument {field} must be a finite positive decimal."
        )
    return format(number.normalize(), "f")


def _check_response_codes(payload: Mapping[str, Any]) -> None:
    """Check both the HTTP API envelope and per-item business result codes."""
    top_code = payload.get("code")
    if top_code is not None and str(top_code) != "0":
        code = str(top_code)[:24]
        if code == "401":
            raise BloFinDemoAuthError("BloFin rejected API authentication (code=401).")
        raise BloFinDemoResponseError(
            f"BloFin rejected the request (code={code})."
        )
    data = payload.get("data")
    rows = data if isinstance(data, list) else [data]
    for row in rows:
        if isinstance(row, dict) and row.get("code") is not None:
            item_code = str(row.get("code"))
            if item_code != "0":
                if item_code == "401":
                    raise BloFinDemoAuthError("BloFin rejected API authentication (code=401).")
                raise BloFinDemoResponseError(
                    f"BloFin rejected an item in the response (code={item_code[:24]})."
                )


def _canonical_query(params: Mapping[str, Any] | None) -> str:
    if not params:
        return ""
    clean = [(str(k), str(v)) for k, v in params.items() if v is not None]
    return urlencode(clean)


def _signature(
    secret: str, method: str, path: str, timestamp: str, nonce: str, body: str = ""
) -> str:
    prehash = f"{path}{method.upper()}{timestamp}{nonce}{body}"
    digest_hex = hmac.new(
        secret.encode("utf-8"), prehash.encode("utf-8"), hashlib.sha256
    ).hexdigest()
    # BloFin signs the hex digest as UTF-8 text, then Base64-encodes those bytes.
    return base64.b64encode(digest_hex.encode("utf-8")).decode("ascii")


class BloFinDemoReadOnly:
    """Read-only REST client pinned to the BloFin Demo API host."""

    def __init__(
        self,
        *,
        api_key: str | None = None,
        api_secret: str | None = None,
        passphrase: str | None = None,
        session: Any = None,
        clock_ms: Any = None,
        timeout: float = 10.0,
    ) -> None:
        # Explicit constructor values win; otherwise standard BloFin account
        # credentials are used before the legacy Demo-prefixed aliases.
        resolved: dict[str, str] = {}
        sources: dict[str, str] = {}
        for field_name, explicit_value in (
            ("api_key", api_key),
            ("api_secret", api_secret),
            ("passphrase", passphrase),
        ):
            if explicit_value is None:
                resolved[field_name], sources[field_name] = _resolve_env_credential(
                    DEMO_READ_CREDENTIAL_ENV[field_name]
                )
            else:
                resolved[field_name] = str(explicit_value).strip()
                sources[field_name] = f"explicit {field_name}"
        self.api_key = resolved["api_key"]
        self.api_secret = resolved["api_secret"]
        self.passphrase = resolved["passphrase"]
        for field_name, credential in resolved.items():
            if any(ord(char) < 33 or ord(char) > 126 for char in credential):
                raise BloFinDemoAuthError(
                    f"{sources[field_name]} contains whitespace, a control character, or a non-ASCII character."
                )
        self.session = session or requests.Session()
        self.clock_ms = clock_ms or (lambda: int(time.time() * 1000))
        self.timeout = timeout
        self.base_url = DEMO_REST_URL

    def _auth_headers(self, path_with_query: str) -> dict[str, str]:
        if not all((self.api_key, self.api_secret, self.passphrase)):
            raise BloFinDemoAuthError(
                "Set BLOFIN_API_KEY, BLOFIN_API_SECRET and BLOFIN_PASSPHRASE, or the legacy Demo-prefixed aliases."
            )
        timestamp = str(int(self.clock_ms()))
        nonce = str(uuid.uuid4())
        return {
            "ACCESS-KEY": self.api_key,
            "ACCESS-SIGN": _signature(
                self.api_secret, "GET", path_with_query, timestamp, nonce
            ),
            "ACCESS-TIMESTAMP": timestamp,
            "ACCESS-NONCE": nonce,
            "ACCESS-PASSPHRASE": self.passphrase,
            "Content-Type": "application/json",
        }

    def _get(
        self,
        path: str,
        *,
        params: Mapping[str, Any] | None = None,
        private: bool = False,
    ) -> Any:
        query = _canonical_query(params)
        path_with_query = f"{path}?{query}" if query else path
        headers = self._auth_headers(path_with_query) if private else {}
        url = f"{self.base_url}{path_with_query}"
        for attempt in range(3):
            try:
                response = self.session.get(
                    url, headers=headers, timeout=self.timeout,
                    allow_redirects=False,
                )
                status_code = int(getattr(response, "status_code", 0) or 0)
                if 300 <= status_code < 400:
                    raise BloFinDemoHTTPError(status_code)
                response.raise_for_status()
                payload = response.json()
                break
            except requests.HTTPError as exc:
                status = getattr(getattr(exc, "response", None), "status_code", None)
                if status == 429 and attempt < 2:
                    retry_header = getattr(exc.response, "headers", {}).get("Retry-After")
                    try:
                        server_delay = max(0.0, float(retry_header))
                    except (TypeError, ValueError):
                        server_delay = 0.0
                    time.sleep(max(server_delay, min(0.5 * (2 ** attempt), 4.0)))
                    continue
                if status == 401:
                    raise BloFinDemoAuthError("BloFin rejected API authentication (HTTP 401).") from exc
                if status == 403:
                    # BloFin documents a temporary firewall ban of about five minutes.
                    # Do not hammer the endpoint; let the caller schedule a later retry.
                    raise BloFinDemoHTTPError(403, retry_after_seconds=300.0) from exc
                if status == 429:
                    raise BloFinDemoHTTPError(429, retry_after_seconds=4.0) from exc
                raise BloFinDemoError("BloFin Demo request failed.") from exc
            except requests.RequestException as exc:
                raise BloFinDemoError("BloFin Demo request failed.") from exc
            except (TypeError, ValueError) as exc:
                raise BloFinDemoResponseError("BloFin returned invalid JSON.") from exc
        else:
            raise BloFinDemoHTTPError(429, retry_after_seconds=4.0)
        if not isinstance(payload, dict):
            raise BloFinDemoResponseError("BloFin response must be a JSON object.")
        _check_response_codes(payload)
        if "data" not in payload:
            raise BloFinDemoResponseError("BloFin response is missing the data field.")
        return payload["data"]

    # Public market-data endpoints: no API key is sent.
    def get_futures_instruments(
        self, *, inst_id: str | None = None, api_permission: str | None = None
    ) -> Any:
        if api_permission not in {None, "full", "reduce_only"}:
            raise ValueError("api_permission must be 'full' or 'reduce_only'.")
        return self._get(
            "/api/v1/market/instruments",
            params={"instId": inst_id, "apiPermission": api_permission},
        )

    def get_tradable_instrument(self, inst_id: str) -> dict[str, Any]:
        """Return validated linear USDT contract metadata only when API permission is full."""
        if not inst_id or not isinstance(inst_id, str):
            raise ValueError("inst_id is required.")
        rows = self.get_futures_instruments(inst_id=inst_id, api_permission="full")
        if not isinstance(rows, list):
            raise BloFinDemoResponseError("Instrument response is not a list.")
        match = next(
            (row for row in rows if isinstance(row, dict) and row.get("instId") == inst_id),
            None,
        )
        if match is None or match.get("apiPermission") != "full":
            raise BloFinDemoResponseError("Instrument is not fully enabled for API trading.")
        if match.get("state") != "live" or match.get("contractType") != "linear":
            raise BloFinDemoResponseError("Only live linear contracts are accepted.")
        if match.get("settleCurrency") != "USDT":
            raise BloFinDemoResponseError("Only USDT-settled contracts are accepted in this phase.")
        try:
            values = {
                field: _positive_decimal_text(match[field], field)
                for field in ("contractValue", "minSize", "lotSize", "tickSize")
            }
            if match.get("maxMarketSize") not in (None, ""):
                values["maxMarketSize"] = _positive_decimal_text(
                    match["maxMarketSize"], "maxMarketSize"
                )
        except KeyError as exc:
            raise BloFinDemoResponseError("Instrument contract metadata is incomplete.") from exc
        return {**match, **values}

    def get_tickers(self, *, inst_id: str | None = None) -> Any:
        return self._get("/api/v1/market/tickers", params={"instId": inst_id})

    def get_mark_price(self, *, inst_id: str) -> Any:
        """Read the dedicated exchange mark-price feed, not the last-trade ticker."""
        if not inst_id or not isinstance(inst_id, str):
            raise ValueError("inst_id is required.")
        return self._get("/api/v1/market/mark-price", params={"instId": inst_id})

    def get_candles(
        self, inst_id: str, *, bar: str = "1m", limit: int = 100
    ) -> Any:
        if not inst_id or not isinstance(limit, int) or not 1 <= limit <= 300:
            raise ValueError("inst_id is required and limit must be between 1 and 300.")
        return self._get(
            "/api/v1/market/candles",
            params={"instId": inst_id, "bar": bar, "limit": limit},
        )

    def get_funding_rate_history(self, *, inst_id: str, limit: int = 100) -> Any:
        """Read recent funding settlements; classification remains the caller's duty."""
        if not inst_id or not isinstance(limit, int) or isinstance(limit, bool) or not 1 <= limit <= 100:
            raise ValueError("inst_id is required and limit must be between 1 and 100.")
        rows = self._get(
            "/api/v1/market/funding-rate-history",
            params={"instId": inst_id, "limit": limit},
        )
        if not isinstance(rows, list):
            raise BloFinDemoResponseError("Funding history response is not a list.")
        return rows

    # Private endpoints: READ permission only.
    def get_position_mode(self) -> dict[str, Any]:
        result = self._get("/api/v1/account/position-mode", private=True)
        if not isinstance(result, dict):
            raise BloFinDemoResponseError("Position-mode response is invalid.")
        mode = result.get("positionMode")
        if mode not in {"net_mode", "long_short_mode"}:
            raise BloFinDemoResponseError("Position mode is missing or unsupported.")
        return result

    def get_futures_balance(self, *, product_type: str = "USDT-FUTURES") -> Any:
        return self._get(
            "/api/v1/account/balance",
            params={"productType": product_type},
            private=True,
        )

    def get_positions(self, *, inst_id: str | None = None) -> Any:
        return self._get(
            "/api/v1/account/positions",
            params={"instId": inst_id},
            private=True,
        )

    def get_open_orders(self, *, inst_id: str | None = None) -> Any:
        return self._get(
            "/api/v1/trade/orders-pending",
            params={"instId": inst_id},
            private=True,
        )

    def get_api_key_info(self) -> dict[str, Any]:
        """Read permission metadata for the exact API key used by this client."""
        result = self._get("/api/v1/user/query-apikey", private=True)
        if not isinstance(result, dict):
            raise BloFinDemoResponseError("BloFin API-key information is not an object.")
        returned_key = result.get("apiKey")
        if not isinstance(returned_key, str) or not hmac.compare_digest(
            returned_key, self.api_key
        ):
            raise BloFinDemoAuthError(
                "BloFin API-key identity could not be confirmed for this credential."
            )
        raw_read_only = result.get("readOnly")
        valid_integer = isinstance(raw_read_only, int) and not isinstance(raw_read_only, bool) and raw_read_only in (0, 1)
        valid_string = isinstance(raw_read_only, str) and raw_read_only.strip() in {"0", "1"}
        if not (valid_integer or valid_string):
            raise BloFinDemoResponseError(
                "BloFin API-key readOnly permission is missing or invalid."
            )
        read_only = int(raw_read_only)
        return {"readOnly": read_only, "trade_permission": read_only == 0}

    def get_open_tpsl_orders(
        self, *, inst_id: str | None = None,
        client_order_id: str | None = None, tpsl_id: str | None = None,
        limit: int = 100,
    ) -> Any:
        """Read active exchange-managed TP/SL orders by instrument, client id or TPSL id."""
        if not isinstance(limit, int) or isinstance(limit, bool) or not 1 <= limit <= 100:
            raise ValueError("limit must be between 1 and 100.")
        if client_order_id is not None and not str(client_order_id).strip():
            raise ValueError("client_order_id must be non-empty when provided.")
        if tpsl_id is not None and not str(tpsl_id).strip():
            raise ValueError("tpsl_id must be non-empty when provided.")
        return self._get(
            "/api/v1/trade/orders-tpsl-pending",
            params={
                "instId": inst_id, "clientOrderId": client_order_id,
                "tpslId": tpsl_id, "limit": str(limit),
            },
            private=True,
        )

    def get_tpsl_orders_history(self, *, inst_id: str | None = None, limit: int = 100) -> Any:
        """Read completed, canceled or triggered TP/SL order history."""
        if not isinstance(limit, int) or isinstance(limit, bool) or not 1 <= limit <= 100:
            raise ValueError("limit must be between 1 and 100.")
        return self._get(
            "/api/v1/trade/orders-tpsl-history",
            params={"instId": inst_id, "limit": str(limit)},
            private=True,
        )

    def get_order_detail(self, inst_id: str, *, client_order_id: str) -> Any:
        """Read one order by its client id so an ambiguous POST is never retried blindly."""
        if not inst_id or not client_order_id:
            raise ValueError("inst_id and client_order_id are required.")
        return self._get(
            "/api/v1/trade/order-detail",
            params={"instId": inst_id, "clientOrderId": client_order_id},
            private=True,
        )

    def get_fills_history(
        self, *, inst_id: str, order_id: str | None = None, limit: int = 100
    ) -> Any:
        """Read actual futures fills for an instrument or one specific order."""
        if not inst_id or not isinstance(limit, int) or not 1 <= limit <= 100:
            raise ValueError("inst_id is required and limit must be between 1 and 100.")
        return self._get(
            "/api/v1/trade/fills-history",
            params={"instId": inst_id, "orderId": order_id, "limit": str(limit)},
            private=True,
        )

    def get_orders_history(
        self, *, inst_id: str, limit: int = 20
    ) -> Any:
        """Read completed futures orders, newest first."""
        if not inst_id or not isinstance(limit, int) or not 1 <= limit <= 100:
            raise ValueError("inst_id is required and limit must be between 1 and 100.")
        return self._get(
            "/api/v1/trade/orders-history",
            params={"instId": inst_id, "limit": str(limit)},
            private=True,
        )

    def get_positions_history(
        self, *, inst_id: str, state: str | None = None, limit: int = 20
    ) -> Any:
        """Read closed/partially-closed position history with actual close time and PnL."""
        if not inst_id or not isinstance(limit, int) or not 1 <= limit <= 100:
            raise ValueError("inst_id is required and limit must be between 1 and 100.")
        if state is not None and state not in {
            "partially_closed", "closed", "liquidated", "partially_liquidated", "adl"
        }:
            raise ValueError("Unsupported position-history state.")
        return self._get(
            "/api/v1/account/positions-history",
            params={"instId": inst_id, "state": state, "limit": str(limit)},
            private=True,
        )

    def check_clock_skew(self, *, inst_id: str = "BTC-USDT") -> dict[str, int]:
        """Estimate exchange clock offset from the exchange timestamp in ticker data."""
        rows = self.get_tickers(inst_id=inst_id)
        if not isinstance(rows, list) or not rows or not isinstance(rows[0], dict):
            raise BloFinDemoResponseError("Ticker timestamp is unavailable.")
        try:
            exchange_ms = int(rows[0]["ts"])
        except (KeyError, TypeError, ValueError) as exc:
            raise BloFinDemoResponseError("Ticker timestamp is invalid.") from exc
        local_ms = int(self.clock_ms())
        offset_ms = exchange_ms - local_ms
        return {"exchange_time_ms": exchange_ms, "local_time_ms": local_ms, "offset_ms": offset_ms}

    def websocket_login_args(self) -> dict[str, str]:
        """Build the authenticated private-WebSocket login payload; sends no trade action."""
        if not all((self.api_key, self.api_secret, self.passphrase)):
            raise BloFinDemoAuthError(
                "Set BLOFIN_API_KEY, BLOFIN_API_SECRET and BLOFIN_PASSPHRASE, or the legacy Demo-prefixed aliases."
            )
        timestamp = str(int(self.clock_ms()))
        nonce = str(uuid.uuid4())
        sign = _signature(self.api_secret, "GET", WS_LOGIN_PATH, timestamp, nonce)
        return {
            "apiKey": self.api_key,
            "passphrase": self.passphrase,
            "timestamp": timestamp,
            "sign": sign,
            "nonce": nonce,
        }

    @staticmethod
    def websocket_urls() -> dict[str, str]:
        return {"public": DEMO_PUBLIC_WS_URL, "private": DEMO_PRIVATE_WS_URL}
