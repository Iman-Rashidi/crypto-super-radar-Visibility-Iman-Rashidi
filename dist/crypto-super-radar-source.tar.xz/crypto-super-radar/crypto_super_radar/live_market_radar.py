"""Live, cross-validated candle radar and non-repainting swing alerts.

The module is signal-only. It does not place orders or integrate with Paper Bot.
Signals use completed candles only; the currently-forming candle is chart-only.
"""
from __future__ import annotations

import copy
import math
import threading
import time
from datetime import datetime, timezone
from typing import Any

import numpy as np
import pandas as pd

from .providers import _ohlcv_frame

from .elliott_waves import monitor_elliott_waves
from .market_patterns import analyze_market_patterns
from .market_flow import analyze_market_flow

INTERVAL_MS = {
    "1s": 1_000,
    "1m": 60_000,
    "5m": 300_000,
    "15m": 900_000,
    "1h": 3_600_000,
    "4h": 14_400_000,
    "1d": 86_400_000,
    "1w": 604_800_000,
    "1M": 2_592_000_000,  # approximate duration for display/cache only; boundaries use calendar months
}
BYBIT_INTERVAL = {
    "1m": "1",
    "5m": "5",
    "15m": "15",
    "1h": "60",
    "4h": "240",
    "1d": "D",
    "1w": "W",
    "1M": "M",
}
PIVOT_RADIUS = 3
MAX_CANDLES = 240
MAX_CANDLE_DISCREPANCY_PCT = 0.40
SIGNAL_MAX_PIVOT_AGE_BARS = 10

# Elliott pivot floors are timeframe-aware. A daily 3% threshold on 1m/5m
# candles suppresses every useful intraday swing and leaves the wave panel empty.
ELLIOTT_MIN_REVERSAL_PCT = {
    "1s": 0.0005,
    "1m": 0.0008,
    "5m": 0.0015,
    "15m": 0.0025,
    "1h": 0.0040,
    "4h": 0.0080,
    "1d": 0.0150,
    "1w": 0.0250,
    "1M": 0.0300,
}



# Public fallback feeds for deployments whose egress IP is rate-limited by Binance.
OKX_BAR = {
    "1m": "1m", "5m": "5m", "15m": "15m", "1h": "1H",
    "4h": "4H", "1d": "1Dutc", "1w": "1Wutc", "1M": "1Mutc",
}
KRAKEN_INTERVAL = {"1m": 1, "5m": 5, "15m": 15, "1h": 60, "4h": 240, "1d": 1440, "1w": 10080}


# Process-local OHLCV + analysis cache. Per-key locks prevent duplicate upstream
# fetches when the same dashboard card is requested concurrently.
LIVE_MARKET_RADAR_CACHE_TTL_SECONDS = 45
_LIVE_MARKET_RADAR_CACHE: dict[tuple[str, str], dict[str, Any]] = {}
_LIVE_MARKET_RADAR_CACHE_LOCK = threading.RLock()
# Compatibility aliases retained for existing offline API tests and diagnostics.
LIVE_MARKET_RADAR_CACHE = _LIVE_MARKET_RADAR_CACHE
LIVE_MARKET_RADAR_CACHE_LOCK = _LIVE_MARKET_RADAR_CACHE_LOCK
_LIVE_MARKET_RADAR_KEY_LOCKS: dict[tuple[str, str], threading.Lock] = {}
_LIVE_MARKET_RADAR_KEY_LOCKS_GUARD = threading.Lock()


def live_market_radar_key_lock(key: tuple[str, str]) -> threading.Lock:
    with _LIVE_MARKET_RADAR_KEY_LOCKS_GUARD:
        return _LIVE_MARKET_RADAR_KEY_LOCKS.setdefault(key, threading.Lock())


def get_live_market_radar_cache(
    key: tuple[str, str], *, now: float | None = None, allow_expired: bool = False,
) -> tuple[dict[str, Any], float] | None:
    current = time.monotonic() if now is None else float(now)
    with _LIVE_MARKET_RADAR_CACHE_LOCK:
        entry = _LIVE_MARKET_RADAR_CACHE.get(key)
        if not isinstance(entry, dict):
            return None
        age = max(0.0, current - float(entry.get("cached_at", 0.0)))
        if age >= LIVE_MARKET_RADAR_CACHE_TTL_SECONDS and not allow_expired:
            return None
        return copy.deepcopy(entry["payload"]), age


def set_live_market_radar_cache(
    key: tuple[str, str], payload: dict[str, Any], *, now: float | None = None,
) -> None:
    current = time.monotonic() if now is None else float(now)
    with _LIVE_MARKET_RADAR_CACHE_LOCK:
        _LIVE_MARKET_RADAR_CACHE[key] = {
            "cached_at": current, "payload": copy.deepcopy(payload),
        }
        while len(_LIVE_MARKET_RADAR_CACHE) > 60:
            oldest = min(_LIVE_MARKET_RADAR_CACHE, key=lambda item: _LIVE_MARKET_RADAR_CACHE[item]["cached_at"])
            _LIVE_MARKET_RADAR_CACHE.pop(oldest, None)


COINBASE_GRANULARITY = {
    "1m": 60, "5m": 300, "15m": 900, "1h": 3600, "1d": 86400,
}


def fetch_coinbase_candles(http: Any, symbol: str, interval: str, limit: int = 240) -> pd.DataFrame:
    """Fetch Coinbase Exchange public candles where its product/timeframe exists."""
    if interval not in COINBASE_GRANULARITY:
        raise ValueError(f"Coinbase Exchange does not support interval {interval!r}")
    instrument = _usdt_instrument(symbol)
    payload = http.get_with_timeout(
        f"https://api.exchange.coinbase.com/products/{instrument}/candles",
        {"granularity": COINBASE_GRANULARITY[interval]},
        timeout=1.35,
    )
    if not isinstance(payload, list) or not payload:
        raise ValueError("Coinbase Exchange returned no candle rows")
    # Coinbase rows: [time, low, high, open, close, volume].
    rows = []
    for row in payload[:max(35, min(int(limit), 300))]:
        if not isinstance(row, (list, tuple)) or len(row) < 6:
            continue
        rows.append({
            "timestamp": pd.to_datetime(row[0], unit="s", utc=True),
            "open": row[3], "high": row[2], "low": row[1],
            "close": row[4], "volume": row[5],
        })
    frame = pd.DataFrame(rows)
    if frame.empty:
        raise ValueError("Coinbase Exchange returned no valid OHLCV candles")
    return frame.set_index("timestamp").sort_index().tail(max(35, min(int(limit), 300)))


def _usdt_instrument(symbol: str) -> str:
    normalized = str(symbol or "").strip().upper()
    if not normalized.endswith("USDT") or len(normalized) <= 4 or not normalized.isascii() or not normalized.isalnum():
        raise ValueError("Fallback feeds support explicit USDT spot symbols only")
    return normalized[:-4] + "-USDT"



def fetch_bybit_candles(http: Any, symbol: str, interval: str, limit: int = 240) -> pd.DataFrame:
    """Fetch Bybit Spot OHLCV with one bounded request and normalize its rows."""
    if interval not in BYBIT_INTERVAL:
        raise ValueError(f"Bybit does not support interval {interval!r}")
    payload = http.get_with_timeout(
        "https://api.bybit.com/v5/market/kline",
        {"category": "spot", "symbol": str(symbol).upper(),
         "interval": BYBIT_INTERVAL[interval], "limit": max(35, min(int(limit), 300))},
        timeout=1.35,
    )
    if not isinstance(payload, dict) or str(payload.get("retCode")) != "0":
        detail = payload.get("retMsg") if isinstance(payload, dict) else "invalid JSON"
        raise ValueError(f"Bybit candle API error: {str(detail)[:160]}")
    rows = ((payload.get("result") or {}).get("list") or [])
    frame = _ohlcv_frame(rows)
    if frame.empty:
        raise ValueError("Bybit returned no valid OHLCV candles")
    return frame.tail(max(35, min(int(limit), 300)))


def fetch_okx_candles(http: Any, symbol: str, interval: str, limit: int = 240) -> pd.DataFrame:
    """Fetch and validate public OKX OHLCV candles with a strict bounded timeout."""
    normalized_interval = str(interval or "").strip()
    if normalized_interval not in OKX_BAR:
        raise ValueError(f"OKX does not support interval {normalized_interval!r}")
    payload = http.get_with_timeout(
        "https://www.okx.com/api/v5/market/candles",
        {"instId": _usdt_instrument(symbol), "bar": OKX_BAR[normalized_interval],
         "limit": str(max(35, min(int(limit), 300)))},
        timeout=1.35,
    )
    if not isinstance(payload, dict) or str(payload.get("code")) != "0":
        raise ValueError(f"OKX candle API error: {str((payload or {}).get('msg') if isinstance(payload, dict) else 'invalid JSON')[:160]}")
    rows = payload.get("data")
    if not isinstance(rows, list) or not rows:
        raise ValueError("OKX returned no candle rows")
    frame = _ohlcv_frame(rows)
    if frame.empty:
        raise ValueError("OKX returned no valid OHLCV candles")
    return frame.tail(max(35, min(int(limit), 300)))


def fetch_kraken_candles(http: Any, symbol: str, interval: str, limit: int = 240) -> pd.DataFrame:
    """Fetch Kraken public OHLC and normalize its VWAP/volume response safely."""
    normalized_interval = str(interval or "").strip()
    if normalized_interval not in KRAKEN_INTERVAL:
        raise ValueError(f"Kraken does not support interval {normalized_interval!r}")
    base = str(symbol or "").strip().upper()
    if not base.endswith("USDT") or len(base) <= 4 or not base.isascii() or not base.isalnum():
        raise ValueError("Kraken fallback supports explicit USDT spot symbols only")
    asset = base[:-4]
    if asset == "BTC":
        asset = "XBT"
    pair = asset + "USDT"
    payload = http.get_with_timeout(
        "https://api.kraken.com/0/public/OHLC",
        {"pair": pair, "interval": KRAKEN_INTERVAL[normalized_interval]},
        timeout=1.35,
    )
    if not isinstance(payload, dict) or payload.get("error"):
        detail = payload.get("error") if isinstance(payload, dict) else "invalid JSON"
        raise ValueError(f"Kraken OHLC API error: {str(detail)[:160]}")
    result = payload.get("result")
    if not isinstance(result, dict):
        raise ValueError("Kraken OHLC response omitted result")
    series = [(key, value) for key, value in result.items() if key != "last" and isinstance(value, list)]
    if len(series) != 1 or not series[0][1]:
        raise ValueError(f"Kraken returned no unique OHLC series for {pair}")
    rows = []
    for row in series[0][1]:
        if not isinstance(row, (list, tuple)) or len(row) < 7:
            raise ValueError("Kraken returned a malformed OHLC row")
        # Kraken's column 5 is VWAP; column 6 is the actual traded base volume.
        rows.append([row[0], row[1], row[2], row[3], row[4], row[6]])
    frame = _ohlcv_frame(rows)
    if frame.empty:
        raise ValueError("Kraken returned no valid OHLCV candles")
    return frame.tail(max(35, min(int(limit), 300)))


def _interval_end(timestamp: pd.Timestamp, interval: str) -> pd.Timestamp:
    if interval == "1M":
        return timestamp + pd.DateOffset(months=1)
    return timestamp + pd.Timedelta(milliseconds=INTERVAL_MS[interval])


def _utc_frame(frame: pd.DataFrame, *, now: pd.Timestamp) -> pd.DataFrame:
    required = {"open", "high", "low", "close", "volume"}
    if not isinstance(frame, pd.DataFrame) or frame.empty or not required.issubset(frame.columns):
        raise ValueError("provider returned no complete OHLCV history")
    if not isinstance(frame.index, pd.DatetimeIndex) or frame.index.has_duplicates:
        raise ValueError("candle timestamps must be unique")
    data = frame.loc[:, ["open", "high", "low", "close", "volume"]].copy()
    if data.index.tz is None:
        data.index = data.index.tz_localize("UTC")
    else:
        data.index = data.index.tz_convert("UTC")
    data = data.sort_index()
    for column in ("open", "high", "low", "close", "volume"):
        data[column] = pd.to_numeric(data[column], errors="coerce")
    values = data[["open", "high", "low", "close", "volume"]].to_numpy(dtype=float)
    invalid = (
        ~np.isfinite(values).all(axis=1)
        | (data[["open", "high", "low", "close"]] <= 0).any(axis=1).to_numpy()
        | (data["volume"] < 0).to_numpy()
        | (data["high"] < data["low"]).to_numpy()
        | (data["high"] < data["open"]).to_numpy()
        | (data["high"] < data["close"]).to_numpy()
        | (data["low"] > data["open"]).to_numpy()
        | (data["low"] > data["close"]).to_numpy()
    )
    if invalid.any():
        raise ValueError("malformed OHLCV candles were returned")
    if data.index[-1] > now + pd.Timedelta(seconds=30):
        raise ValueError("provider returned a future-dated candle")
    return data.loc[data.index <= now].tail(1000)


def _pivots(frame: pd.DataFrame) -> list[dict[str, Any]]:
    """Three-bars-left/right pivots; right-side bars must already be closed."""
    radius = PIVOT_RADIUS
    if len(frame) < radius * 2 + 5:
        return []
    highs = frame["high"].to_numpy(dtype=float)
    lows = frame["low"].to_numpy(dtype=float)
    times = frame.index
    result: list[dict[str, Any]] = []
    for index in range(radius, len(frame) - radius):
        left_high = highs[index-radius:index]
        right_high = highs[index+1:index+radius+1]
        left_low = lows[index-radius:index]
        right_low = lows[index+1:index+radius+1]
        is_high = highs[index] > float(np.max(left_high)) and highs[index] >= float(np.max(right_high))
        is_low = lows[index] < float(np.min(left_low)) and lows[index] <= float(np.min(right_low))
        # Ambiguous outside bars are not labelled as both a top and a bottom.
        if is_high == is_low:
            continue
        kind = "HIGH" if is_high else "LOW"
        result.append({
            "kind": kind,
            "index": int(index),
            "price": float(highs[index] if is_high else lows[index]),
            "timestamp": times[index].isoformat(),
            "confirmed_at": times[index + radius].isoformat(),
            "confirmation_delay_bars": radius,
        })
    return result[-12:]


def _atr(frame: pd.DataFrame, period: int = 14) -> float | None:
    if len(frame) < period + 1:
        return None
    high = frame["high"].to_numpy(dtype=float)
    low = frame["low"].to_numpy(dtype=float)
    close = frame["close"].to_numpy(dtype=float)
    previous = np.r_[close[0], close[:-1]]
    true_range = np.maximum(high - low, np.maximum(np.abs(high - previous), np.abs(low - previous)))
    value = float(np.mean(true_range[-period:]))
    return value if math.isfinite(value) and value > 0 else None


def _relative_difference_pct(left: float, right: float) -> float:
    denominator = (abs(left) + abs(right)) / 2.0
    return 0.0 if denominator == 0 else abs(left - right) / denominator * 100.0


def _signal(
    frame: pd.DataFrame,
    pivots: list[dict[str, Any]],
    *,
    quality_status: str,
    freshness_status: str,
    divergence: dict[str, Any] | None = None,
) -> dict[str, Any]:
    unknown = {
        "signal": "UNKNOWN",
        "status": "BLOCKED",
        "reason": "Validated candle, freshness, or independent-provider evidence is unavailable.",
        "entry_reference_price": None,
        "stop_loss": None,
        "take_profit": None,
        "reward_risk": None,
        "pivot": None,
        "signal_candle_at": None,
        "signal_key": None,
    }
    if frame.empty or len(frame) < 35:
        return {**unknown, "reason": "At least 35 completed candles are required."}
    if quality_status != "PASS":
        return {**unknown, "reason": "A BUY/SELL alert requires aligned candles from two independent venues."}
    if freshness_status != "FRESH":
        return {**unknown, "reason": "The last completed candle is stale; no new alert is emitted."}

    latest = frame.iloc[-1]
    previous = frame.iloc[-2]
    entry = float(latest["close"])
    atr = _atr(frame)
    if atr is None:
        return {**unknown, "reason": "ATR volatility could not be calculated."}
    if not pivots:
        return {**unknown, "signal": "WAIT", "status": "WAITING",
                "reason": "No confirmed swing pivot is available yet."}

    pivot = pivots[-1]
    pivot_index = int(pivot["index"])
    bars_since_pivot_confirmation = (len(frame) - 1) - (pivot_index + PIVOT_RADIUS)
    if bars_since_pivot_confirmation < 0 or bars_since_pivot_confirmation > SIGNAL_MAX_PIVOT_AGE_BARS:
        return {**unknown, "signal": "WAIT", "status": "WAITING",
                "reason": "The latest confirmed swing is outside the alert window.",
                "pivot": pivot}
    bullish_reversal = (
        pivot["kind"] == "LOW"
        and entry > float(latest["open"])
        and entry > float(previous["high"])
        and entry > float(pivot["price"])
    )
    bearish_reversal = (
        pivot["kind"] == "HIGH"
        and entry < float(latest["open"])
        and entry < float(previous["low"])
        and entry < float(pivot["price"])
    )
    divergence_type = str((divergence or {}).get("type") or "NONE")
    if bullish_reversal and divergence_type == "BEARISH":
        return {**unknown, "signal": "WAIT", "status": "WAITING",
                "reason": "Bullish entry blocked by a confirmed bearish RSI/price divergence candidate.",
                "pivot": pivot, "signal_candle_at": frame.index[-1].isoformat()}
    if bearish_reversal and divergence_type == "BULLISH":
        return {**unknown, "signal": "WAIT", "status": "WAITING",
                "reason": "Bearish entry blocked by a confirmed bullish RSI/price divergence candidate.",
                "pivot": pivot, "signal_candle_at": frame.index[-1].isoformat()}

    if not bullish_reversal and not bearish_reversal:
        return {
            **unknown,
            "signal": "WAIT",
            "status": "WAITING",
            "reason": "No confirmed reversal trigger beyond the prior candle boundary.",
            "pivot": pivot,
            "signal_candle_at": frame.index[-1].isoformat(),
        }

    if bullish_reversal:
        stop = float(pivot["price"]) - 0.5 * atr
        targets = [float(item["price"]) for item in pivots
                   if item["kind"] == "HIGH" and float(item["price"]) > entry]
        if not targets:
            targets = [float(frame["high"].tail(30).max())]
        target = min((value for value in targets if value > entry), default=None)
        side = "BUY"
        risk = entry - stop
        reward = target - entry if target is not None else None
    else:
        stop = float(pivot["price"]) + 0.5 * atr
        targets = [float(item["price"]) for item in pivots
                   if item["kind"] == "LOW" and float(item["price"]) < entry]
        if not targets:
            targets = [float(frame["low"].tail(30).min())]
        target = max((value for value in targets if value < entry), default=None)
        side = "SELL"
        risk = stop - entry
        reward = entry - target if target is not None else None

    rr = reward / risk if reward is not None and risk > 0 else None
    if rr is None or not math.isfinite(rr) or rr < 1.5:
        return {
            **unknown,
            "signal": "WAIT",
            "status": "WAITING",
            "reason": "Reversal pattern exists, but the structural reward/risk is below 1.5 or no target is available.",
            "pivot": pivot,
            "signal_candle_at": frame.index[-1].isoformat(),
            "entry_reference_price": entry,
            "stop_loss": round(stop, 12),
            "take_profit": round(target, 12) if target is not None else None,
            "reward_risk": round(rr, 3) if rr is not None else None,
        }
    timestamp = frame.index[-1].isoformat()
    return {
        "signal": side,
        "status": "CONFIRMED",
        "reason": (
            "Confirmed swing LOW, bullish close above the previous candle high, and structural reward/risk >= 1.5."
            if side == "BUY" else
            "Confirmed swing HIGH, bearish close below the previous candle low, and structural reward/risk >= 1.5."
        ),
        "entry_reference_price": round(entry, 12),
        "stop_loss": round(stop, 12),
        "take_profit": round(float(target), 12),
        "reward_risk": round(float(rr), 3),
        "pivot": pivot,
        "signal_candle_at": timestamp,
        "signal_key": f"{side}|{timestamp}|{pivot['timestamp']}",
    }


def build_live_market_radar_payload(
    symbol: str,
    interval: str,
    binance_candles: pd.DataFrame,
    bybit_candles: pd.DataFrame | None,
    *,
    now: datetime | None = None,
    bybit_error: str | None = None,
    aggregate_trades: list[dict[str, Any]] | None = None,
    order_book: dict[str, Any] | None = None,
    market_flow_error: str | None = None,
    primary_provider: str = "Binance Spot",
    secondary_provider: str = "Bybit Spot",
) -> dict[str, Any]:
    """Build a chart payload and fail-closed signal from two public OHLCV sources."""
    normalized_symbol = str(symbol or "").strip().upper()
    raw_interval = str(interval or "").strip()
    normalized_interval = raw_interval if raw_interval == "1M" else raw_interval.lower()
    if normalized_interval not in INTERVAL_MS:
        raise ValueError("unsupported candle interval")
    if not normalized_symbol or not normalized_symbol.isascii() or not normalized_symbol.isalnum():
        raise ValueError("invalid market symbol")
    current = pd.Timestamp(now or datetime.now(timezone.utc))
    if current.tzinfo is None:
        current = current.tz_localize("UTC")
    else:
        current = current.tz_convert("UTC")
    interval_ms = INTERVAL_MS[normalized_interval]
    binance = _utc_frame(binance_candles, now=current)
    # Calendar-aware boundaries are required for 1M; seconds and weeks remain exact.
    bar_ends = pd.Series([_interval_end(ts, normalized_interval) for ts in binance.index], index=binance.index)
    # Current/in-progress candle can be drawn, but it is excluded from all signal math.
    display_frame = binance.tail(MAX_CANDLES)
    display_ends = bar_ends.reindex(display_frame.index)
    closed_mask = bar_ends <= current
    closed = binance.loc[closed_mask].copy()
    if closed.empty:
        raise ValueError("no completed candles are available")
    last_closed_end = _interval_end(closed.index[-1], normalized_interval)
    age_seconds = max(0.0, float((current - last_closed_end).total_seconds()))
    freshness_grace_seconds = max((interval_ms / 1000.0) * 1.5, 5.0 if normalized_interval == "1s" else 0.0)
    freshness_status = "FRESH" if age_seconds <= freshness_grace_seconds else "STALE"

    provider_discrepancy = None
    cross_validation = "UNKNOWN"
    cross_reason = bybit_error or f"{secondary_provider} candle history is not available."
    common_count = 0
    bybit = None
    if isinstance(bybit_candles, pd.DataFrame):
        try:
            bybit = _utc_frame(bybit_candles, now=current)
            bybit_ends = pd.Series([_interval_end(ts, normalized_interval) for ts in bybit.index], index=bybit.index)
            bybit_closed = bybit.loc[bybit_ends <= current]
            common = closed[["close"]].join(
                bybit_closed[["close"]], how="inner", lsuffix="_binance", rsuffix="_bybit"
            )
            common_count = int(len(common))
            if common_count >= 5:
                diffs = [
                    _relative_difference_pct(float(a), float(b))
                    for a, b in zip(common["close_binance"].tail(5), common["close_bybit"].tail(5))
                ]
                provider_discrepancy = round(max(diffs), 5)
                if provider_discrepancy <= MAX_CANDLE_DISCREPANCY_PCT:
                    cross_validation = "PASS"
                    cross_reason = f"Last five completed candle closes are aligned across {primary_provider} and {secondary_provider}."
                else:
                    cross_validation = "FAIL"
                    cross_reason = (
                        f"Maximum close discrepancy across the last five common candles is "
                        f"{provider_discrepancy:.4f}%, above the {MAX_CANDLE_DISCREPANCY_PCT:.2f}% limit."
                    )
            else:
                cross_reason = "Fewer than five common completed candles are available for independent validation."
        except Exception as exc:
            cross_reason = f"{type(exc).__name__}: {str(exc)[:160]}"
    quality_status = cross_validation

    pivots = _pivots(closed)
    wave = monitor_elliott_waves(
        closed,
        min_reversal_pct=ELLIOTT_MIN_REVERSAL_PCT[normalized_interval],
        max_reversal_pct=0.15,
    )
    wave_pivots = []
    wave_count = wave.get("wave_count")
    raw_wave_pivots = wave.get("pivots") if isinstance(wave.get("pivots"), list) else []
    if (
        wave.get("pattern") in {"BULLISH", "BEARISH"}
        and isinstance(wave_count, int) and wave_count >= 2
        and len(raw_wave_pivots) >= wave_count + 1
    ):
        selected_wave_points = raw_wave_pivots[-(wave_count + 1):]
        for point_index, point in enumerate(selected_wave_points):
            wave_pivots.append({
                "timestamp": point["timestamp"],
                "price": float(point["price"]),
                "kind": point["kind"],
                "label": "مبدأ" if point_index == 0 else f"W{point_index}",
            })
    elif raw_wave_pivots:
        # Preserve confirmed structural swings on the chart without pretending
        # that an ambiguous sequence is a valid numbered Elliott impulse.
        for point in raw_wave_pivots:
            wave_pivots.append({
                "timestamp": point["timestamp"],
                "price": float(point["price"]),
                "kind": point["kind"],
                "label": "سقف ساختاری" if point["kind"] == "HIGH" else "کف ساختاری",
            })
    market_analysis = analyze_market_patterns(closed, pivots, wave)
    market_flow = analyze_market_flow(
        closed, aggregate_trades=aggregate_trades, order_book=order_book, now=current.to_pydatetime()
    )
    if market_flow_error:
        market_flow["live_flow_error"] = str(market_flow_error)[:180]
    market_analysis["data_quality"] = {
        "pattern_data_source": primary_provider,
        "freshness_status": freshness_status,
        "cross_validation_status": cross_validation,
        "signal_eligible": quality_status == "PASS" and freshness_status == "FRESH",
        "reason": (
            f"Patterns use completed {primary_provider} candles; trade alerts still require fresh, aligned {primary_provider} and {secondary_provider} candles."
        ),
    }
    signal = _signal(
        closed, pivots, quality_status=quality_status, freshness_status=freshness_status,
        divergence=market_analysis.get("direction", {}).get("divergence"),
    )
    chart = []
    for timestamp, row in display_frame.iterrows():
        opened = _interval_end(timestamp, normalized_interval)
        is_closed = opened <= current
        chart.append({
            "time": int(timestamp.timestamp() * 1000),
            "open": float(row["open"]),
            "high": float(row["high"]),
            "low": float(row["low"]),
            "close": float(row["close"]),
            "volume": float(row["volume"]),
            "is_closed": bool(is_closed),
        })
    return {
        "status": "PASS" if freshness_status == "FRESH" else "STALE",
        "symbol": normalized_symbol,
        "interval": normalized_interval,
        "updated_at_utc": current.isoformat(),
        "last_closed_candle_at": closed.index[-1].isoformat(),
        "candle_age_seconds": round(age_seconds, 2),
        "freshness_status": freshness_status,
        "cross_validation": {
            "status": cross_validation,
            "providers": [primary_provider] + ([secondary_provider] if bybit is not None else []),
            "common_completed_candles": common_count,
            "max_close_discrepancy_pct": provider_discrepancy,
            "reason": cross_reason,
            "limit_pct": MAX_CANDLE_DISCREPANCY_PCT,
        },
        "candles": chart,
        "pivots": pivots,
        "wave_pivots": wave_pivots,
        "elliott_waves": wave,
        "market_analysis": market_analysis,
        "market_flow": market_flow,
        "signal": signal,
        "signal_only": True,
        "paper_bot_connected": False,
        "orders_submitted": False,
        "disclaimer": (
            "Signal alerts are based on completed candles and confirmed swings. "
            "The in-progress candle is display-only. No alert predicts the absolute market top or bottom."
        ),
    }
