"""Free public market-data adapters for GeckoTerminal, DexScreener, Binance and Bybit."""

from __future__ import annotations

import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import urlparse

import pandas as pd
import requests

from .config import AppConfig
from .models import AssetSpec, MarketSnapshot
from .rate_limiter import SharedRateLimiter


class DataProviderError(RuntimeError):
    pass


NETWORKS = {"solana": "solana", "base": "base", "eth": "eth"}
DEX_CHAINS = {"solana": "solana", "base": "base", "eth": "ethereum"}


class PublicHttpClient:
    def __init__(self, config: AppConfig):
        self.config = config
        self.limiter = SharedRateLimiter(config.rate_limits.host_intervals)
        self.headers = {
            "User-Agent": config.user_agent,
            "Accept": "application/json",
        }

    def request_json(self, method: str, url: str, **kwargs: Any) -> Any:
        kwargs.setdefault("timeout", self.config.request_timeout_seconds)
        headers = dict(self.headers)
        headers.update(kwargs.pop("headers", {}) or {})
        last_error: Optional[Exception] = None
        for attempt in range(self.config.max_http_retries):
            self.limiter.wait(url)
            try:
                response = requests.request(method, url, headers=headers, **kwargs)
                if response.status_code == 429:
                    retry_after = response.headers.get("Retry-After")
                    delay = float(retry_after) if retry_after and retry_after.isdigit() else min(2 ** attempt, 20)
                    time.sleep(delay)
                    response.raise_for_status()
                if response.status_code >= 500:
                    response.raise_for_status()
                response.raise_for_status()
                try:
                    return response.json()
                except ValueError as exc:
                    raise DataProviderError(f"Non-JSON response from {urlparse(url).netloc}") from exc
            except (requests.RequestException, DataProviderError) as exc:
                last_error = exc
                if attempt + 1 < self.config.max_http_retries:
                    time.sleep(min(2 ** attempt, 8))
        raise DataProviderError(f"Request failed for {urlparse(url).netloc}: {last_error}") from last_error

    def get(self, url: str, params: Optional[dict] = None) -> Any:
        return self.request_json("GET", url, params=params)

    def post(self, url: str, payload: dict) -> Any:
        return self.request_json("POST", url, json=payload, headers={"Content-Type": "application/json"})


class GeckoTerminalProvider:
    BASE = "https://api.geckoterminal.com/api/v2"

    def __init__(self, http: PublicHttpClient):
        self.http = http

    @staticmethod
    def _num(value: Any) -> Optional[float]:
        try:
            result = float(value)
            return result if pd.notna(result) and result >= 0 else None
        except (TypeError, ValueError):
            return None

    def token_pool(self, chain: str, address: str) -> Dict[str, Any]:
        network = NETWORKS[chain]
        url = f"{self.BASE}/networks/{network}/tokens/{address}/pools"
        payload = self.http.get(url, params={"page": 1, "include": "base_token,quote_token"})
        pools = payload.get("data") or []
        included = {item.get("id"): item.get("attributes", {}) for item in payload.get("included", []) if isinstance(item, dict)}
        candidates = []
        for pool in pools:
            attrs = pool.get("attributes") or {}
            base_id = ((pool.get("relationships") or {}).get("base_token") or {}).get("data", {}).get("id")
            quote_id = ((pool.get("relationships") or {}).get("quote_token") or {}).get("data", {}).get("id")
            base_attrs = included.get(base_id, {})
            quote_attrs = included.get(quote_id, {})
            base_address = (base_attrs.get("address") or "").lower()
            quote_address = (quote_attrs.get("address") or "").lower()
            if base_address == address.lower():
                price = self._num(attrs.get("base_token_price_usd"))
            elif quote_address == address.lower():
                price = self._num(attrs.get("quote_token_price_usd"))
            else:
                # The token pools endpoint generally returns the token as base;
                # if no relationship match is available, do not guess a price.
                price = None
            liquidity = self._num(attrs.get("reserve_in_usd"))
            volume = self._num((attrs.get("volume_usd") or {}).get("h24"))
            if price is not None and liquidity is not None and volume is not None:
                candidates.append({
                    "price": price,
                    "liquidity": liquidity,
                    "volume_24h": volume,
                    "pool_address": attrs.get("address"),
                    "created_at": attrs.get("pool_created_at"),
                    "raw": attrs,
                })
        if not candidates:
            raise DataProviderError("GeckoTerminal returned no pool with a verifiable token-side USD price")
        return max(candidates, key=lambda item: item["liquidity"])

    def candles(self, chain: str, pool_address: str, token_address: Optional[str] = None, timeframe: str = "day", aggregate: int = 1, limit: int = 365) -> pd.DataFrame:
        network = NETWORKS[chain]
        url = f"{self.BASE}/networks/{network}/pools/{pool_address}/ohlcv/{timeframe}"
        token_selector = token_address if token_address else "base"
        payload = self.http.get(url, params={"aggregate": aggregate, "limit": limit, "currency": "usd", "token": token_selector})
        rows = (((payload.get("data") or {}).get("attributes") or {}).get("ohlcv_list") or [])
        return _ohlcv_frame(rows)


class DexScreenerProvider:
    BASE = "https://api.dexscreener.com"

    def __init__(self, http: PublicHttpClient):
        self.http = http

    def token_pair(self, chain: str, address: str) -> Dict[str, Any]:
        url = f"{self.BASE}/token-pairs/v1/{DEX_CHAINS[chain]}/{address}"
        payload = self.http.get(url)
        pairs = payload if isinstance(payload, list) else payload.get("pairs", [])
        usable = []
        for pair in pairs or []:
            base = pair.get("baseToken") or {}
            liquidity = _safe_float((pair.get("liquidity") or {}).get("usd"))
            price = _safe_float(pair.get("priceUsd"))
            volume = _safe_float((pair.get("volume") or {}).get("h24"))
            if (base.get("address") or "").lower() != address.lower():
                continue
            if price is None or liquidity is None or volume is None:
                continue
            usable.append({
                "price": price,
                "liquidity": liquidity,
                "volume_24h": volume,
                "pair_address": pair.get("pairAddress"),
                "created_at_ms": pair.get("pairCreatedAt"),
                "raw": pair,
            })
        if not usable:
            raise DataProviderError("DexScreener returned no usable pair where the requested asset is the base token")
        return max(usable, key=lambda item: item["liquidity"])


class BinanceProvider:
    BASE = "https://api.binance.com"

    def __init__(self, http: PublicHttpClient):
        self.http = http

    def ticker(self, symbol: str) -> Dict[str, float]:
        price = self.http.get(f"{self.BASE}/api/v3/ticker/price", {"symbol": symbol})
        stats = self.http.get(f"{self.BASE}/api/v3/ticker/24hr", {"symbol": symbol})
        p = _safe_float(price.get("price"))
        vol = _safe_float(stats.get("quoteVolume"))
        if p is None or vol is None:
            raise DataProviderError(f"Binance returned incomplete ticker for {symbol}")
        return {"price": p, "volume_24h": vol, "raw": stats}

    def candles(self, symbol: str, interval: str = "1d", limit: int = 365) -> pd.DataFrame:
        payload = self.http.get(f"{self.BASE}/api/v3/klines", {"symbol": symbol, "interval": interval, "limit": min(limit, 1000)})
        return _ohlcv_frame(payload)


class BybitProvider:
    BASE = "https://api.bybit.com"

    def __init__(self, http: PublicHttpClient):
        self.http = http

    def ticker(self, symbol: str) -> Dict[str, float]:
        payload = self.http.get(f"{self.BASE}/v5/market/tickers", {"category": "spot", "symbol": symbol})
        items = ((payload.get("result") or {}).get("list") or [])
        if not items:
            raise DataProviderError(f"Bybit has no spot ticker for {symbol}")
        item = items[0]
        p = _safe_float(item.get("lastPrice"))
        vol = _safe_float(item.get("turnover24h"))
        if p is None or vol is None:
            raise DataProviderError(f"Bybit returned incomplete ticker for {symbol}")
        return {"price": p, "volume_24h": vol, "raw": item}

    def candles(self, symbol: str, interval: str = "D", limit: int = 365) -> pd.DataFrame:
        payload = self.http.get(f"{self.BASE}/v5/market/kline", {"category": "spot", "symbol": symbol, "interval": interval, "limit": min(limit, 1000)})
        rows = ((payload.get("result") or {}).get("list") or [])
        # Bybit order: startTime, open, high, low, close, volume, turnover.
        return _ohlcv_frame(rows)


class SolanaRpcProvider:
    URL = "https://api.mainnet-beta.solana.com"

    def __init__(self, http: PublicHttpClient):
        self.http = http

    def _rpc(self, method: str, params: list) -> Any:
        payload = self.http.post(self.URL, {"jsonrpc": "2.0", "id": 1, "method": method, "params": params})
        if payload.get("error"):
            raise DataProviderError(f"Solana RPC {method}: {payload['error']}")
        return (payload.get("result") or {}).get("value")

    def token_security(self, mint: str) -> Dict[str, Any]:
        account = self._rpc("getAccountInfo", [mint, {"encoding": "jsonParsed", "commitment": "confirmed"}])
        if not account:
            raise DataProviderError("Solana mint account not found")
        info = (((account.get("data") or {}).get("parsed") or {}).get("info") or {})
        if not info:
            raise DataProviderError("Solana RPC did not return a parsed mint account")
        mint_authority = info.get("mintAuthority")
        freeze_authority = info.get("freezeAuthority")
        supply_payload = self.http.post(self.URL, {"jsonrpc": "2.0", "id": 1, "method": "getTokenSupply", "params": [mint]})
        supply_value = ((supply_payload.get("result") or {}).get("value") or {})
        total_supply = _safe_float(supply_value.get("uiAmountString"))
        largest = self._rpc("getTokenLargestAccounts", [mint, {"commitment": "confirmed"}]) or []
        top_amounts = [(_safe_float(row.get("uiAmountString")) or 0.0) for row in largest]
        top10_pct = None
        if total_supply and total_supply > 0 and top_amounts:
            top10_pct = min(100.0, sum(top_amounts[:10]) / total_supply * 100.0)
        return {
            "mint_authority_active": mint_authority is not None,
            "freeze_authority_active": freeze_authority is not None,
            "top10_token_account_concentration_pct": top10_pct,
            "mint_authority": mint_authority,
            "freeze_authority": freeze_authority,
            "supply": total_supply,
            "scope_note": "Top-10 token-account concentration is not wallet-owner concentration; LP and exchange accounts may distort it.",
        }


def _safe_float(value: Any) -> Optional[float]:
    try:
        result = float(value)
        return result if pd.notna(result) and result >= 0 else None
    except (TypeError, ValueError):
        return None


def _ohlcv_frame(rows: Any) -> pd.DataFrame:
    """Normalize provider candle rows without inventing missing values."""
    parsed = []
    for row in rows or []:
        if not isinstance(row, (list, tuple)) or len(row) < 6:
            continue
        try:
            ts = int(float(row[0]))
            if ts > 10**12:
                ts = int(ts / 1000)
            values = [_safe_float(x) for x in row[1:6]]
            if any(x is None for x in values):
                continue
            parsed.append((pd.to_datetime(ts, unit="s", utc=True), *values))
        except (TypeError, ValueError, OverflowError):
            continue
    if not parsed:
        return pd.DataFrame(columns=["open", "high", "low", "close", "volume"], index=pd.DatetimeIndex([], tz="UTC", name="timestamp"))
    frame = pd.DataFrame(parsed, columns=["timestamp", "open", "high", "low", "close", "volume"])
    frame = frame.drop_duplicates("timestamp").set_index("timestamp").sort_index()
    return frame.astype(float)


def relative_difference_pct(a: float, b: float) -> float:
    denominator = (abs(a) + abs(b)) / 2.0
    if denominator == 0:
        return 0.0
    return abs(a - b) / denominator * 100.0


class MarketDataService:
    """Fetch and cross-validate two independent public venues/data providers."""

    def __init__(self, config: Optional[AppConfig] = None):
        self.config = config or AppConfig()
        http = PublicHttpClient(self.config)
        self.gecko = GeckoTerminalProvider(http)
        self.dexscreener = DexScreenerProvider(http)
        self.binance = BinanceProvider(http)
        self.bybit = BybitProvider(http)
        self.solana_rpc = SolanaRpcProvider(http)
        self.perpetual = PerpetualMarketProvider(http)

    def snapshot(self, asset: AssetSpec) -> MarketSnapshot:
        from concurrent.futures import ThreadPoolExecutor
        threshold = self.config.thresholds.provider_discrepancy_pct
        with ThreadPoolExecutor(max_workers=2) as executor:
            if asset.market_type == "dex":
                future_a = executor.submit(self.gecko.token_pool, asset.chain, asset.address)
                future_b = executor.submit(self.dexscreener.token_pair, asset.chain, asset.address)
                a, b = future_a.result(), future_b.result()
                name_a, name_b = "GeckoTerminal", "DexScreener"
            elif asset.market_type == "perp":
                future_a = executor.submit(self.perpetual.binance_ticker, asset.symbol)
                future_b = executor.submit(self.perpetual.bybit_ticker, asset.symbol)
                a, b = future_a.result(), future_b.result()
                funding_diff = abs(a["funding_rate"] - b["funding_rate"])
                if funding_diff > 0.0002:
                    raise DataProviderError(f"Funding-rate discrepancy exceeds 2 bps: {funding_diff:.6f}")
                if a["open_interest"] <= 0 or b["open_interest"] <= 0:
                    raise DataProviderError("Open interest is zero or unavailable")
                name_a, name_b = "Binance USD-M", "Bybit Linear"
            else:
                future_a = executor.submit(self.binance.ticker, asset.symbol)
                future_b = executor.submit(self.bybit.ticker, asset.symbol)
                a, b = future_a.result(), future_b.result()
                name_a, name_b = "Binance Spot", "Bybit Spot"
        price_diff = relative_difference_pct(a["price"], b["price"])
        # DEX providers describe the same token/pool universe, so both price
        # and volume are compared. CEX venues have different traded volumes by
        # definition; compare prices there and screen each venue's turnover
        # independently instead of falsely requiring equal exchange volumes.
        volume_diff = relative_difference_pct(a["volume_24h"], b["volume_24h"]) if asset.market_type == "dex" else None
        if price_diff > threshold or (volume_diff is not None and volume_diff > threshold):
            volume_detail = f", volume discrepancy={volume_diff:.2f}%" if volume_diff is not None else ""
            raise DataProviderError(
                f"Cross-validation rejected asset: price discrepancy={price_diff:.2f}%"
                f"{volume_detail} (limit={threshold:.2f}%)"
            )
        liquidity_values = [v for v in (a.get("liquidity"), b.get("liquidity")) if v is not None]
        liquidity = min(liquidity_values) if liquidity_values else None
        return MarketSnapshot(
            asset=asset,
            price_usd=(a["price"] + b["price"]) / 2.0,
            volume_24h_usd=min(a["volume_24h"], b["volume_24h"]),
            liquidity_usd=liquidity,
            price_discrepancy_pct=price_diff,
            volume_discrepancy_pct=volume_diff,
            provider_a=name_a,
            provider_b=name_b,
            pool_address=a.get("pool_address"),
            pool_created_at=a.get("created_at"),
            pair_address=b.get("pair_address"),
            raw={"provider_a": a, "provider_b": b,
                 "funding_rate_8h": ((a.get("funding_rate", 0.0) + b.get("funding_rate", 0.0)) / 2.0) if asset.market_type == "perp" else None,
                 "open_interest_a": a.get("open_interest"), "open_interest_b": b.get("open_interest")},
        )

    def candles(self, asset: AssetSpec, snapshot: MarketSnapshot) -> pd.DataFrame:
        if asset.market_type == "dex":
            if not snapshot.pool_address:
                raise DataProviderError("No validated pool address for OHLCV request")
            return self.gecko.candles(asset.chain, snapshot.pool_address, token_address=asset.address, timeframe="day", aggregate=1, limit=365)
        if asset.market_type == "perp":
            return self.perpetual.binance_candles(asset.symbol, limit=365)
        return self.binance.candles(asset.symbol, interval="1d", limit=365)

    def benchmark_candles(self) -> pd.DataFrame:
        return self.binance.candles("BTCUSDT", interval="1d", limit=365)

    def funding_history(self, asset: AssetSpec) -> pd.Series:
        if asset.market_type != "perp":
            return pd.Series(dtype=float)
        return self.perpetual.funding_history(asset.symbol)

    def security(self, asset: AssetSpec) -> Dict[str, Any]:
        if asset.market_type in {"cex", "perp"}:
            # Only major native assets have an explicit allowlist in this prototype.
            if asset.symbol in {"BTCUSDT", "ETHUSDT", "SOLUSDT"}:
                return {"status": "PASS", "reason": "Native major asset; token-contract authority checks are not applicable.", "scope": "Exchange/custody and market risks remain; listing is not a guarantee of safety."}
            return {"status": "UNKNOWN", "reason": "CEX instrument is not in the conservative native-asset allowlist."}
        if asset.chain == "solana":
            return {"status": "KNOWN", **self.solana_rpc.token_security(asset.address)}
        # Generic EVM bytecode/owner inspection is not sufficient to certify
        # mint, blacklist, proxy, honeypot and admin-role risks. Fail closed.
        return {
            "status": "UNKNOWN",
            "reason": "EVM token security is not certified by a generic free public-RPC check; no trade is allowed.",
        }

class PerpetualMarketProvider:
    """Public Binance USD-M / Bybit linear perpetual market data."""

    BINANCE = "https://fapi.binance.com"
    BYBIT = "https://api.bybit.com"

    def __init__(self, http: PublicHttpClient):
        self.http = http

    def binance_ticker(self, symbol: str) -> Dict[str, Any]:
        price = self.http.get(f"{self.BINANCE}/fapi/v1/ticker/price", {"symbol": symbol})
        stats = self.http.get(f"{self.BINANCE}/fapi/v1/ticker/24hr", {"symbol": symbol})
        premium = self.http.get(f"{self.BINANCE}/fapi/v1/premiumIndex", {"symbol": symbol})
        oi = self.http.get(f"{self.BINANCE}/fapi/v1/openInterest", {"symbol": symbol})
        values = {
            "price": _safe_float(price.get("price")),
            "volume_24h": _safe_float(stats.get("quoteVolume")),
            "funding_rate": _safe_float(premium.get("lastFundingRate")),
            "open_interest": _safe_float(oi.get("openInterest")),
        }
        if any(values[k] is None for k in values):
            raise DataProviderError(f"Binance Futures returned incomplete ticker for {symbol}")
        return {**values, "raw": {"ticker": stats, "premium": premium, "open_interest": oi}}

    def bybit_ticker(self, symbol: str) -> Dict[str, Any]:
        payload = self.http.get(f"{self.BYBIT}/v5/market/tickers", {"category": "linear", "symbol": symbol})
        items = ((payload.get("result") or {}).get("list") or [])
        if not items:
            raise DataProviderError(f"Bybit Linear has no market for {symbol}")
        item = items[0]
        values = {
            "price": _safe_float(item.get("lastPrice")),
            "volume_24h": _safe_float(item.get("turnover24h")),
            "funding_rate": _safe_float(item.get("fundingRate")),
            "open_interest": _safe_float(item.get("openInterest")),
        }
        if any(values[k] is None for k in values):
            raise DataProviderError(f"Bybit Linear returned incomplete ticker for {symbol}")
        return {**values, "raw": item}

    def binance_candles(self, symbol: str, limit: int = 365) -> pd.DataFrame:
        rows = self.http.get(f"{self.BINANCE}/fapi/v1/klines", {"symbol": symbol, "interval": "1d", "limit": min(limit, 1000)})
        return _ohlcv_frame(rows)

    def funding_history(self, symbol: str, limit: int = 1000) -> pd.Series:
        """Fetch public historical funding; returns 8-hour funding rate indexed by UTC time."""
        binance_rows = self.http.get(f"{self.BINANCE}/fapi/v1/fundingRate", {"symbol": symbol, "limit": min(limit, 1000)})
        bybit_payload = self.http.get(f"{self.BYBIT}/v5/market/funding/history", {"category": "linear", "symbol": symbol, "limit": 200})
        bybit_rows = ((bybit_payload.get("result") or {}).get("list") or [])
        def series_from(rows: Any, ts_key: str, rate_key: str) -> pd.Series:
            parsed = []
            for row in rows or []:
                try:
                    stamp = int(row[ts_key])
                    rate = float(row[rate_key])
                    parsed.append((pd.to_datetime(stamp, unit="ms", utc=True), rate))
                except (KeyError, TypeError, ValueError, OverflowError):
                    continue
            if not parsed:
                return pd.Series(dtype=float)
            return pd.Series({ts: rate for ts, rate in parsed}).sort_index()
        binance = series_from(binance_rows, "fundingTime", "fundingRate")
        bybit = series_from(bybit_rows, "fundingRateTimestamp", "fundingRate")
        if binance.empty or bybit.empty:
            raise DataProviderError("Historical funding unavailable from both venues")
        # Verify latest funding observations are close in time and value.
        latest_a, latest_b = binance.iloc[-1], bybit.iloc[-1]
        if abs(float(latest_a) - float(latest_b)) > 0.0002:
            raise DataProviderError("Funding rates diverge by more than 2 bps between venues")
        # Use the common overlapping period, averaging rates at the same timestamp.
        common = binance.index.intersection(bybit.index)
        if len(common) >= 3:
            return ((binance.loc[common] + bybit.loc[common]) / 2.0).sort_index()
        # If timestamps are not identical, use nearest Bybit observation only when close.
        left = binance.rename("binance").reset_index().rename(columns={"index": "timestamp"}).sort_values("timestamp")
        right = bybit.rename("bybit").reset_index().rename(columns={"index": "timestamp"}).sort_values("timestamp")
        merged = pd.merge_asof(left, right, on="timestamp", direction="nearest", tolerance=pd.Timedelta("10min"))
        merged = merged.dropna()
        if len(merged) < 3:
            raise DataProviderError("Insufficient overlapping historical funding observations")
        merged["funding"] = (merged["binance"] + merged["bybit"]) / 2.0
        return pd.Series(merged["funding"].to_numpy(), index=pd.DatetimeIndex(merged["timestamp"])).sort_index()
