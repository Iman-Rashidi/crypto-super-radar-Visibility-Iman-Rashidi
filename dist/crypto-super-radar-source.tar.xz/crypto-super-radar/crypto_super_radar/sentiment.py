"""Transparent local headline scoring; no hidden paid NLP dependency."""

from __future__ import annotations

import re
from typing import Dict, Iterable, Optional


POSITIVE_TERMS = {
    "adoption", "partnership", "integration", "approval", "approved",
    "launch", "upgrade", "listing", "inflow", "record high", "bullish",
    "mainnet", "funding", "institutional", "accumulation",
}
NEGATIVE_TERMS = {
    "hack", "exploit", "rug pull", "scam", "fraud", "lawsuit", "ban",
    "delist", "bankruptcy", "insolvency", "breach", "paused withdrawals",
    "mint exploit", "bridge attack", "outflow", "liquidation cascade",
}
LEADER_TERMS = {"elon musk", "vitalik buterin", "cz", "changpeng zhao", "michael saylor", "brian armstrong"}
HYPE_TERMS = {"trending", "viral", "explodes", "parabolic", "moon", "massive rally", "surges", "pump", "breaking", "100x"}


def score_headlines(headlines: Iterable[str]) -> Dict[str, Optional[float]]:
    texts = [str(item).strip().lower() for item in headlines if item and str(item).strip()]
    if not texts:
        return {"score": None, "hype_score": None, "status": "UNKNOWN", "positive_hits": 0, "negative_hits": 0,
                "leader_mentions": 0, "hype_term_hits": 0,
                "reason": "No headlines supplied; sentiment is not inferred from silence."}
    positive_hits = 0
    negative_hits = 0
    leader_mentions = 0
    hype_term_hits = 0
    for text in texts:
        normalized = re.sub(r"\s+", " ", text)
        positive_hits += sum(term in normalized for term in POSITIVE_TERMS)
        negative_hits += sum(term in normalized for term in NEGATIVE_TERMS)
        leader_mentions += sum(term in normalized for term in LEADER_TERMS)
        hype_term_hits += sum(term in normalized for term in HYPE_TERMS)
    raw = 50.0 + 12.0 * positive_hits - 18.0 * negative_hits
    score = max(0.0, min(100.0, raw))
    # This is input-batch hype intensity, not a statistically measured time-series spike.
    hype_score = min(100.0, 10.0 * len(texts) + 20.0 * leader_mentions + 15.0 * hype_term_hits)
    return {
        "score": score,
        "hype_score": hype_score,
        "status": "KNOWN",
        "positive_hits": positive_hits,
        "negative_hits": negative_hits,
        "leader_mentions": leader_mentions,
        "hype_term_hits": hype_term_hits,
        "reason": "Rule-based local keyword score; not a trained model or a live news feed. Hype is batch intensity, not a historical spike detector.",
    }
