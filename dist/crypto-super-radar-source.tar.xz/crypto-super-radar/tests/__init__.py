"""Automated test suite."""
