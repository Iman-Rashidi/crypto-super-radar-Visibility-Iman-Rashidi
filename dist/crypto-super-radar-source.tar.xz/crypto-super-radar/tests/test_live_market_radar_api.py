from __future__ import annotations

import atexit
import json
import threading
import time
import unittest
from datetime import datetime, timezone
from http.client import HTTPConnection
from http.server import ThreadingHTTPServer
from unittest.mock import patch

import pandas as pd

from crypto_super_radar import web_app
from crypto_super_radar.web_app import Handler


def _close_web_app_test_database_connections():
    resources = (
        web_app.ENGINE.data,
        web_app.ENGINE.whale_store,
        web_app.PAPER_BOT.ledger,
        web_app.FUTURES_PAPER_BOT.ledger,
    )
    for resource in resources:
        close = getattr(resource, "close", None)
        if callable(close):
            close()


atexit.register(_close_web_app_test_database_connections)


class QuietHandler(Handler):
    def log_message(self, fmt, *args):
        pass


def candle_frame():
    start = datetime(2025, 1, 1, 0, 0, tzinfo=timezone.utc)
    rows = []
    for i in range(61):
        base = 100.0
        opened, high, low, close = base, base + 1.0, base - 1.0, base + 0.2
        if i == 50:
            opened, high, low, close = 106.0, 110.0, 105.0, 108.0
        if i == 55:
            opened, high, low, close = 92.0, 94.0, 90.0, 91.0
        if i in (56, 57, 58):
            opened, high, low, close = 92.0, 94.0 + (i - 56) * 0.2, 91.5, 93.0
        if i == 59:
            opened, high, low, close = 93.0, 96.0, 92.5, 95.5
        if i == 60:
            opened, high, low, close = 95.5, 97.0, 95.0, 96.5
        rows.append({"open": opened, "high": high, "low": low, "close": close, "volume": 1000.0})
    return pd.DataFrame(rows, index=pd.date_range(start=start, periods=61, freq="5min"))


class LiveMarketRadarApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), QuietHandler)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.host, cls.port = cls.server.server_address

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(timeout=2)

    def request(self, path):
        connection = HTTPConnection(self.host, self.port, timeout=5)
        connection.request("GET", path)
        response = connection.getresponse()
        status = response.status
        payload = response.read()
        connection.close()
        return status, payload

    def setUp(self):
        with web_app.LIVE_MARKET_RADAR_CACHE_LOCK:
            web_app.LIVE_MARKET_RADAR_CACHE.clear()

    def test_api_returns_two_source_candles_waves_and_signal(self):
        frame = candle_frame()
        def public_get(url, params=None):
            if "/depth" in url:
                return {"bids": [], "asks": []}
            if "cryptocompare" in url:
                return {"Data": []}
            return []
        with patch.object(web_app.ENGINE.data.binance, "candles", return_value=frame) as binance, \
             patch.object(web_app.ENGINE.data.bybit, "candles", return_value=frame.copy()) as bybit, \
             patch.object(web_app.ENGINE.data.binance.http, "get", side_effect=public_get), \
             patch("crypto_super_radar.live_market_radar.datetime") as clock:
            clock.now.return_value = datetime(2025, 1, 1, 5, 3, tzinfo=timezone.utc)
            clock.side_effect = lambda *args, **kwargs: datetime(*args, **kwargs)
            status, raw_payload = self.request(
                "/api/live-market-radar?symbol=BTCUSDT&interval=5m&refresh=1"
            )
        payload = json.loads(raw_payload)
        self.assertEqual(status, 200)
        self.assertEqual(payload["cross_validation"]["status"], "PASS")
        self.assertEqual(payload["signal"]["signal"], "BUY")
        self.assertTrue(payload["candles"][-1]["is_closed"] is False)
        self.assertEqual(payload["signal"]["signal_candle_at"], payload["last_closed_candle_at"])
        self.assertFalse(payload["orders_submitted"])
        self.assertIn("future_forecast", payload)
        self.assertEqual(len(payload["future_forecast"]["confidence_band"]), 12)
        self.assertIn("higher_timeframes", payload["future_forecast"])
        self.assertEqual(payload["future_forecast"]["news_summary_fa"], "داده تأییدشده موجود نیست")
        self.assertEqual(binance.call_count, 6)
        self.assertEqual({call.kwargs.get("interval") for call in binance.call_args_list}, {"5m", "1h", "4h", "1d", "1w", "1M"})
        self.assertTrue(all(call.kwargs.get("limit") == 180 for call in binance.call_args_list))
        bybit.assert_called_once()

    def test_one_second_interval_uses_fast_binance_only_fallback(self):
        frame = candle_frame()
        frame.index = pd.date_range("2025-01-01T00:00:00Z", periods=len(frame), freq="1s")
        started = time.monotonic()
        with patch.object(web_app.ENGINE.data.binance, "candles", return_value=frame) as binance, \
             patch.object(web_app.ENGINE.data.bybit, "candles") as bybit:
            payload = web_app._live_market_radar_payload("BTCUSDT", "1s", force_refresh=True)
        elapsed = time.monotonic() - started
        self.assertLess(elapsed, 2.0)
        binance.assert_called_once_with("BTCUSDT", interval="1s", limit=180)
        bybit.assert_not_called()
        self.assertEqual(payload["source_mode"], "SINGLE_SOURCE")
        self.assertIn("Binance", payload["source_status_fa"])
        self.assertEqual(payload["cross_validation"]["status"], "UNKNOWN")
        self.assertEqual(payload["signal"]["status"], "BLOCKED")
        self.assertFalse(payload["orders_submitted"])

    def test_missing_second_provider_blocks_buy_sell_signal(self):
        frame = candle_frame()
        def public_get(url, params=None):
            if "/depth" in url:
                return {"bids": [], "asks": []}
            if "cryptocompare" in url:
                return {"Data": []}
            return []
        with patch.object(web_app.ENGINE.data.binance, "candles", return_value=frame), \
             patch.object(web_app.ENGINE.data.bybit, "candles", side_effect=RuntimeError("rate limited")), \
             patch.object(web_app.ENGINE.data.binance.http, "get", side_effect=public_get):
            status, raw_payload = self.request(
                "/api/live-market-radar?symbol=BTCUSDT&interval=5m&refresh=1"
            )
        payload = json.loads(raw_payload)
        self.assertEqual(status, 200)
        self.assertEqual(payload["cross_validation"]["status"], "UNKNOWN")
        self.assertNotIn(payload["signal"]["signal"], {"BUY", "SELL"})
        self.assertEqual(payload["signal"]["status"], "BLOCKED")

    def test_valid_custom_symbol_is_normalized_and_sent_to_spot_analyzer(self):
        expected = {"symbol": "UNKNOWNUSDT", "status": "OK", "candles": [], "orders_submitted": False}
        with patch.object(web_app, "_live_market_radar_payload", return_value=expected) as builder:
            status, raw_payload = self.request(
                "/api/live-market-radar?symbol=unknown&interval=5m"
            )
        payload = json.loads(raw_payload)
        self.assertEqual(status, 200)
        self.assertEqual(payload["symbol"], "UNKNOWNUSDT")
        builder.assert_called_once_with("UNKNOWNUSDT", "5m", force_refresh=False)

    def test_home_page_includes_live_candle_controls_in_paper_bot(self):
        connection = HTTPConnection(self.host, self.port, timeout=5)
        connection.request("GET", "/")
        response = connection.getresponse()
        status = response.status
        page = response.read().decode("utf-8")
        connection.close()
        self.assertEqual(status, 200)
        self.assertIn('id="live-market-radar"', page)
        self.assertIn('id="live-candle-chart"', page)
        self.assertIn('id="live-radar-custom-symbol"', page)
        self.assertIn('id="live-radar-custom-search"', page)
        self.assertIn('id="live-wave-watch-grid"', page)
        for symbol in ("BTCUSDT", "ETHUSDT", "SOLUSDT", "XRPUSDT", "LINKUSDT"):
            self.assertIn(symbol, page)
        self.assertIn("refreshWaveWatchlist", page)
        self.assertIn("نمایش روی نمودار بزرگ", page)
        self.assertIn('/api/live-market-radar', page)


if __name__ == "__main__":
    unittest.main()
